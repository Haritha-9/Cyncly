"""Case Study 1 settings, deliberately small for a reproducible local POC."""
from dataclasses import dataclass
from pathlib import Path
import os


@dataclass(frozen=True)
class Settings:
    data_dir: Path
    tenant_keys: dict[str, str]
    admin_key: str
    max_upload_bytes: int = 8 * 1024 * 1024
    max_image_edge: int = 4096


def get_settings() -> Settings:
    raw = os.getenv("TENANT_KEYS", "alpha:alpha-demo-key,beta:beta-demo-key")
    keys = dict(part.split(":", 1) for part in raw.split(",") if ":" in part)
    if not keys:
        raise RuntimeError("TENANT_KEYS must define at least one tenant")
    return Settings(
        data_dir=Path(os.getenv("DATA_DIR", "./data")).resolve(),
        tenant_keys=keys,
        admin_key=os.getenv("ADMIN_KEY", "local-admin-demo-key"),
    )
