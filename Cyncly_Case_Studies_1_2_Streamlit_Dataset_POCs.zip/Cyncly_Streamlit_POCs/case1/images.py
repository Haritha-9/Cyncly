"""Input validation, EXIF rotation, normalization, simple quality features."""
from io import BytesIO
from PIL import Image, ImageOps, ImageStat, UnidentifiedImageError
from fastapi import HTTPException
import hashlib

SUPPORTED = {"JPEG": "image/jpeg", "PNG": "image/png", "WEBP": "image/webp"}
Image.MAX_IMAGE_PIXELS = 4096 * 4096


def decode_image(payload: bytes, max_bytes: int, max_edge: int):
    if not payload:
        raise HTTPException(422, "Image is empty")
    if len(payload) > max_bytes:
        raise HTTPException(413, "Image is too large")
    try:
        original = Image.open(BytesIO(payload))
        format_name = original.format
        if format_name not in SUPPORTED:
            raise HTTPException(415, "Only JPEG, PNG and WebP are supported")
        original.load()
        width, height = original.size
        if min(width, height) < 32 or max(width, height) > max_edge:
            raise HTTPException(422, f"Image dimensions must be 32-{max_edge} pixels on each side")
        image = ImageOps.exif_transpose(original).convert("RGB")
        # Always normalize storage to PNG, dropping EXIF and embedded metadata.
        output = BytesIO()
        image.save(output, format="PNG")
        gray = image.convert("L")
        brightness = round(ImageStat.Stat(gray).mean[0], 2)
        contrast = round(ImageStat.Stat(gray).stddev[0], 2)
        return image, output.getvalue(), {
            "width": image.width,
            "height": image.height,
            "brightness": brightness,
            "contrast": contrast,
            "sha256": hashlib.sha256(payload).hexdigest(),
            "source_format": format_name,
        }
    except HTTPException:
        raise
    except (UnidentifiedImageError, OSError, ValueError, Image.DecompressionBombError) as exc:
        raise HTTPException(422, f"Invalid or unsupported image: {type(exc).__name__}") from exc
