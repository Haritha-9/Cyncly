"""Case Study 1 API: online object detection, storage, metrics, feedback, rollout.
Run: uvicorn case1.main:app --port 8001 --reload
"""
from contextlib import asynccontextmanager
import json
import logging
import statistics
import time
from uuid import uuid4

from fastapi import BackgroundTasks, Depends, FastAPI, File, Header, HTTPException, Request, UploadFile
from prometheus_client import CONTENT_TYPE_LATEST, Counter, Histogram, generate_latest
from starlette.responses import Response
from pydantic import BaseModel, Field

from .auth import tenant_auth, admin_auth
from .config import Settings, get_settings
from .detection import DetectorFactory
from .images import decode_image
from .registry import Registry
from .storage import Store

logger = logging.getLogger("cyncly.case1")
REQUESTS = Counter("cv_poc_predictions_total", "Predictions by tenant and model", ["tenant", "model"])
LATENCY = Histogram("cv_poc_inference_seconds", "Prediction latency", ["tenant", "model"])


class Feedback(BaseModel):
    accepted: bool
    missed_labels: list[str] = Field(default_factory=list, max_length=20)
    corrected_labels: list[str] = Field(default_factory=list, max_length=20)


class Rollout(BaseModel):
    active: str
    canary: str | None = None
    canary_percent: int = Field(ge=0, le=100, default=0)


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or get_settings()
    store = Store(settings.data_dir)
    registry = Registry(settings.data_dir)
    factory = DetectorFactory()
    app = FastAPI(title="Cyncly Case 1 - Detection POC", version="0.1.0",
                  description="Synthetic-marker demo by default; optionally real YOLO weights.")
    app.state.settings, app.state.store, app.state.registry = settings, store, registry

    def predict_and_save(payload: bytes, tenant: str, prediction_id: str):
        start = time.perf_counter()
        image, normalized, features = decode_image(payload, settings.max_upload_bytes, settings.max_image_edge)
        model_id, config = registry.assigned_model(tenant, prediction_id)
        try:
            boxes = factory.get(model_id, config).predict(image)
        except Exception as exc:
            logger.exception("detector_unavailable tenant=%s model=%s", tenant, model_id)
            raise HTTPException(503, f"Detector '{model_id}' unavailable; check optional model installation") from exc
        latency_ms = round((time.perf_counter() - start) * 1000, 2)
        store.save_image(tenant, prediction_id, normalized)
        with store.connection() as db:
            db.execute("""INSERT INTO predictions
                (id,tenant_id,image_sha,model_version,backend,boxes_json,features_json,latency_ms)
                VALUES (?,?,?,?,?,?,?,?)""",
                (prediction_id,tenant,features["sha256"],model_id,config["backend"],
                 json.dumps(boxes),json.dumps(features),latency_ms))
        REQUESTS.labels(tenant=tenant, model=model_id).inc()
        LATENCY.labels(tenant=tenant, model=model_id).observe(latency_ms / 1000)
        logger.info("prediction_id=%s tenant=%s model=%s boxes=%d latency_ms=%.1f",
                    prediction_id,tenant,model_id,len(boxes),latency_ms)
        return {"prediction_id": prediction_id, "tenant_id": tenant,
                "model_version": model_id, "backend": config["backend"],
                "demo_only": config["backend"] == "marker",
                "image_quality": {k: features[k] for k in ("width","height","brightness","contrast")},
                "detections": boxes, "latency_ms": latency_ms}

    @app.get("/health")
    def health():
        return {"status": "ok", "service": "case1"}

    @app.get("/metrics")
    def metrics():
        return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)

    @app.post("/v1/predict")
    async def predict(request: Request, file: UploadFile = File(...), tenant: str = Depends(tenant_auth)):
        payload = await file.read(settings.max_upload_bytes + 1)
        return predict_and_save(payload, tenant, str(uuid4()))

    @app.get("/v1/predictions/{prediction_id}")
    def read_prediction(prediction_id: str, tenant: str = Depends(tenant_auth)):
        with store.connection() as db:
            row = db.execute("SELECT * FROM predictions WHERE id=? AND tenant_id=?", (prediction_id,tenant)).fetchone()
        if not row:
            raise HTTPException(404, "Prediction not found")
        return {"prediction_id": row["id"], "tenant_id": row["tenant_id"],
                "model_version": row["model_version"], "backend": row["backend"],
                "detections": json.loads(row["boxes_json"]),
                "image_quality": json.loads(row["features_json"]), "latency_ms": row["latency_ms"]}

    @app.post("/v1/predictions/{prediction_id}/feedback")
    def feedback(prediction_id: str, data: Feedback, tenant: str = Depends(tenant_auth)):
        with store.connection() as db:
            row = db.execute("SELECT id FROM predictions WHERE id=? AND tenant_id=?", (prediction_id,tenant)).fetchone()
            if not row:
                raise HTTPException(404, "Prediction not found")
            db.execute("""INSERT INTO feedback (prediction_id,tenant_id,accepted,missed_labels_json,corrected_labels_json)
                       VALUES (?,?,?,?,?)""", (prediction_id,tenant,int(data.accepted),
                       json.dumps(data.missed_labels),json.dumps(data.corrected_labels)))
        return {"saved": True, "purpose": "human feedback and future annotation review"}

    @app.post("/v1/jobs", status_code=202)
    async def create_job(background_tasks: BackgroundTasks, file: UploadFile = File(...), tenant: str = Depends(tenant_auth)):
        payload = await file.read(settings.max_upload_bytes + 1)
        # Validate before queueing; background execution happens in this single process only.
        decode_image(payload, settings.max_upload_bytes, settings.max_image_edge)
        job_id = str(uuid4())
        with store.connection() as db:
            db.execute("""CREATE TABLE IF NOT EXISTS jobs
                (id TEXT PRIMARY KEY, tenant_id TEXT, status TEXT, prediction_json TEXT, error TEXT)""")
            db.execute("INSERT INTO jobs (id,tenant_id,status) VALUES (?,?,?)",(job_id,tenant,"queued"))

        def run_job():
            with store.connection() as db:
                db.execute("UPDATE jobs SET status='running' WHERE id=?", (job_id,))
            try:
                output = predict_and_save(payload,tenant,job_id)
                with store.connection() as db:
                    db.execute("UPDATE jobs SET status='complete',prediction_json=? WHERE id=?",
                               (json.dumps(output),job_id))
            except Exception:
                logger.exception("job_failed id=%s", job_id)
                with store.connection() as db:
                    db.execute("UPDATE jobs SET status='failed',error=? WHERE id=?",
                               ("Inference failed; check service logs",job_id))
        background_tasks.add_task(run_job)
        return {"job_id": job_id, "status": "queued", "warning": "POC in-process task; not durable"}

    @app.get("/v1/jobs/{job_id}")
    def get_job(job_id: str, tenant: str = Depends(tenant_auth)):
        with store.connection() as db:
            row = db.execute("SELECT * FROM jobs WHERE id=? AND tenant_id=?", (job_id,tenant)).fetchone()
        if not row:
            raise HTTPException(404, "Job not found")
        return {"job_id": job_id, "status": row["status"],
                "prediction": json.loads(row["prediction_json"]) if row["prediction_json"] else None,
                "error": row["error"]}

    @app.get("/v1/analytics/tenant")
    def tenant_analytics(tenant: str = Depends(tenant_auth)):
        with store.connection() as db:
            rows = db.execute("SELECT latency_ms,model_version,features_json FROM predictions WHERE tenant_id=?", (tenant,)).fetchall()
            feeds = db.execute("SELECT accepted,missed_labels_json FROM feedback WHERE tenant_id=?", (tenant,)).fetchall()
        latencies = sorted(float(r["latency_ms"]) for r in rows)
        p95 = latencies[max(0, int(len(latencies)*0.95 + 0.9999)-1)] if latencies else None
        missed = sum(bool(json.loads(r["missed_labels_json"])) for r in feeds)
        return {"tenant_id": tenant, "prediction_count": len(rows), "feedback_count": len(feeds),
                "user_reported_miss_feedback_count": missed,
                "user_reported_miss_rate": round(missed/len(feeds),3) if feeds else None,
                "feedback_acceptance_rate": round(sum(r["accepted"] for r in feeds)/len(feeds),3) if feeds else None,
                "p95_latency_ms": p95,
                "model_versions": sorted({r["model_version"] for r in rows}),
                "note": "Reported misses are a proxy; true recall requires reviewed ground-truth bounding boxes."}

    @app.get("/v1/analytics/drift")
    def drift(tenant: str = Depends(tenant_auth)):
        with store.connection() as db:
            rows = db.execute("""SELECT features_json FROM predictions WHERE tenant_id=?
                                  ORDER BY rowid DESC LIMIT 40""", (tenant,)).fetchall()
        values = [json.loads(r["features_json"]) for r in rows]
        recent, reference = values[:20], values[20:40]
        if len(recent) < 5 or len(reference) < 5:
            return {"status": "insufficient_samples", "minimum_per_window": 5,
                    "recent": len(recent), "reference": len(reference)}
        diffs = {}
        for feature in ("brightness","contrast"):
            now = statistics.mean(v[feature] for v in recent)
            before = statistics.mean(v[feature] for v in reference)
            diffs[feature] = {"recent_mean": round(now,2), "reference_mean": round(before,2),
                              "absolute_change": round(abs(now-before),2)}
        return {"status": "review" if any(v["absolute_change"] >= 30 for v in diffs.values()) else "stable_by_simple_heuristic",
                "features": diffs,
                "warning": "Toy drift heuristic; production requires approved baselines and segment-level statistical checks."}

    @app.get("/v1/admin/models", dependencies=[Depends(admin_auth)])
    def models():
        return registry.read()

    @app.post("/v1/admin/models/rollout", dependencies=[Depends(admin_auth)])
    def rollout(data: Rollout):
        try:
            return registry.rollout(data.active, data.canary, data.canary_percent)
        except ValueError as exc:
            raise HTTPException(422, str(exc)) from exc

    @app.post("/v1/admin/models/rollback", dependencies=[Depends(admin_auth)])
    def rollback():
        try:
            return registry.rollback()
        except ValueError as exc:
            raise HTTPException(409, str(exc)) from exc

    return app


app = create_app()
