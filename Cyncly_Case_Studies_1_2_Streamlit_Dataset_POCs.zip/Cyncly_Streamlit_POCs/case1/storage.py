"""SQLite metadata repository and local object-store adapter (replaces Postgres/S3 in POC)."""
import sqlite3
from pathlib import Path
from contextlib import contextmanager


class Store:
    def __init__(self, directory: Path):
        self.directory = directory
        self.directory.mkdir(parents=True, exist_ok=True)
        self.images = directory / "images"
        self.images.mkdir(exist_ok=True)
        self.db_file = directory / "case1.sqlite3"
        with self.connection() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS predictions (
                    id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, image_sha TEXT NOT NULL,
                    model_version TEXT NOT NULL, backend TEXT NOT NULL, boxes_json TEXT NOT NULL,
                    features_json TEXT NOT NULL, latency_ms REAL NOT NULL,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP);
                CREATE INDEX IF NOT EXISTS idx_prediction_tenant ON predictions(tenant_id,created_at);
                CREATE TABLE IF NOT EXISTS feedback (
                    id INTEGER PRIMARY KEY AUTOINCREMENT, prediction_id TEXT NOT NULL,
                    tenant_id TEXT NOT NULL, accepted INTEGER NOT NULL,
                    missed_labels_json TEXT NOT NULL, corrected_labels_json TEXT NOT NULL,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP);
                CREATE INDEX IF NOT EXISTS idx_feedback_tenant ON feedback(tenant_id,prediction_id);
                CREATE TABLE IF NOT EXISTS jobs (
                    id TEXT PRIMARY KEY, tenant_id TEXT, status TEXT, prediction_json TEXT, error TEXT);
            """)

    @contextmanager
    def connection(self):
        conn = sqlite3.connect(self.db_file, timeout=15)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        finally:
            conn.close()

    def save_image(self, tenant: str, prediction_id: str, image_bytes: bytes):
        # tenant comes from authenticated allowlist, not client-provided path
        path = self.images / tenant
        path.mkdir(parents=True, exist_ok=True)
        (path / f"{prediction_id}.png").write_bytes(image_bytes)
