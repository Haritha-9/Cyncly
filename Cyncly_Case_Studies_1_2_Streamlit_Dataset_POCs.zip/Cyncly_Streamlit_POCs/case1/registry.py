"""File-based release controls; production replacement would be MLflow + deployment controller."""
from pathlib import Path
import hashlib
import json

DEFAULT = {
    "active": "marker-v1",
    "canary": "marker-v2",
    "canary_percent": 0,
    "models": {
        "marker-v1": {"backend": "marker", "confidence": 0.93},
        "marker-v2": {"backend": "marker", "confidence": 0.88},
        "yolo11n": {"backend": "yolo", "weights": "yolo11n.pt"},
        "fasterrcnn": {"backend": "fasterrcnn"}
    },
    "history": []
}


class Registry:
    def __init__(self, directory: Path):
        self.path = directory / "models.json"
        if not self.path.exists():
            self._write(DEFAULT)

    def _write(self, state: dict):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temp = self.path.with_suffix(".tmp")
        temp.write_text(json.dumps(state, indent=2), encoding="utf8")
        temp.replace(self.path)

    def read(self):
        return json.loads(self.path.read_text(encoding="utf8"))

    def assigned_model(self, tenant: str, request_id: str):
        state = self.read()
        pct = int(state.get("canary_percent", 0))
        if pct and state.get("canary"):
            bucket = int(hashlib.sha256(f"{tenant}:{request_id}".encode()).hexdigest()[:8], 16) % 100
            if bucket < pct:
                selected = state["canary"]
                return selected, state["models"][selected]
        selected = state["active"]
        return selected, state["models"][selected]

    def rollout(self, active: str, canary: str | None, percent: int):
        state = self.read()
        if active not in state["models"] or (canary and canary not in state["models"]):
            raise ValueError("Unknown model version")
        if not 0 <= percent <= 100:
            raise ValueError("canary_percent must be 0-100")
        previous = {key: state[key] for key in ("active", "canary", "canary_percent")}
        state["history"].append(previous)
        state.update(active=active, canary=canary, canary_percent=percent)
        self._write(state)
        return state

    def rollback(self):
        state = self.read()
        if not state["history"]:
            raise ValueError("No previous deployment to restore")
        previous = state["history"].pop()
        state.update(previous)
        self._write(state)
        return state
