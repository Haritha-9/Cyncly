from fastapi import Header, HTTPException, Request
from hmac import compare_digest


def tenant_auth(request: Request, x_tenant_id: str = Header(default=""), x_api_key: str = Header(default="")) -> str:
    expected = request.app.state.settings.tenant_keys.get(x_tenant_id)
    if not expected or not compare_digest(x_api_key, expected):
        raise HTTPException(401, "Invalid tenant credentials")
    return x_tenant_id


def admin_auth(request: Request, x_admin_key: str = Header(default="")) -> None:
    if not compare_digest(x_admin_key, request.app.state.settings.admin_key):
        raise HTTPException(403, "Admin access required")
