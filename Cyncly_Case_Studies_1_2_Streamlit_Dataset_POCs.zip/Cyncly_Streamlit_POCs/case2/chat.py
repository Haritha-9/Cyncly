"""Auditable, deterministic chat flow; no hidden language-model claims."""
import re
from .catalog import CATALOG, BY_SKU


def greeting(mode: str):
    if mode == "manual":
        return "Manual baseline: tell me whether you need a chair, table, couch, bed or book. A human still confirms the product."
    if mode == "cv":
        return "CV-assisted pilot: upload an image. I will suggest product categories, then ask you to confirm."
    return "Advanced-assisted pilot: upload an image. CV provides candidate categories, and I can guide clarification. Optional VLM is disabled unless configured."


def after_image(mode: str, suggestions: list[dict], backend: str, vlm_description: str | None = None):
    intro = f"I found {len(suggestions)} category match(es) using the {backend} detector."
    if backend == "marker":
        intro += " This is a synthetic-marker demo, not real photo recognition."
    if not suggestions:
        return intro + " I cannot identify the object confidently. Please describe it, or type 'human'."
    items = "; ".join(f"{i+1}) {it['name']} ({it['sku']}, confidence {it['confidence']:.2f})"
                       for i,it in enumerate(suggestions[:5]))
    guidance = "These are category-based examples, not exact product matches. Type 'choose 1', 'correct chair', or 'human'."
    extra = (" Optional image description: " + vlm_description[:300]) if vlm_description else ""
    return f"{intro} Suggested: {items}. {guidance}{extra}"


def respond(message: str, suggestions: list[dict]):
    text = message.strip().lower()
    if not text:
        return "Please enter a question or a choice.", None, "awaiting_input"
    if any(word in text for word in ("human", "expert", "agent", "escalate")):
        return "I have flagged this for human review. No product has been selected automatically.", None, "human_review"
    selection = re.fullmatch(r"(?:choose|select|confirm)\s+(\d+)", text)
    if selection:
        index = int(selection.group(1)) - 1
        if 0 <= index < len(suggestions):
            sku = suggestions[index]["sku"]
            return f"You confirmed {suggestions[index]['name']} ({sku}). Please verify dimensions/material in the catalogue before purchase.", sku, "confirmed"
        return "That option is not available. Type 'show options' to see your choices.", None, "awaiting_input"
    if text in ("show", "show options", "options", "what did you find", "what can you see"):
        if not suggestions:
            return "No matches yet. Upload an image or type 'correct chair' to search the sample catalogue.", None, "awaiting_input"
        return "Available: " + "; ".join(f"{i+1}) {x['name']}" for i,x in enumerate(suggestions)), None, "awaiting_input"
    match = re.search(r"(?:correct|actually|find|need|looking for|it is|it's)\s+(?:a\s+|an\s+)?(chair|table|couch|sofa|bed|book)",text)
    if match or text in ("chair", "table", "couch", "sofa", "bed", "book"):
        term = match.group(1) if match else text
        label = {"table":"dining table","sofa":"couch"}.get(term,term)
        found = [item for item in CATALOG if item["label"] == label]
        if found:
            sku = found[0]["sku"]
            # Do NOT confirm a product merely because it appears in conversational text.
            return f"Possible match: {found[0]['name']} ({sku}). Please type 'choose 1' after I update the suggestions.", found, "suggestions_updated"
    if any(x in text for x in ("why", "confidence", "certain")):
        return "The detector proposes a broad object category. A high detection score is not proof of an exact catalogue SKU. Human confirmation is required.", None, "awaiting_input"
    return "I can show options, help correct a category ('correct chair'), or escalate ('human'). What would you like to do?", None, "awaiting_input"
