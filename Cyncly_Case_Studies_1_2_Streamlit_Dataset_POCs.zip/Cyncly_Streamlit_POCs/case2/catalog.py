"""Tiny mock product catalogue; not Cyncly's actual product catalogue."""
CATALOG = [
    {"sku":"DEMO-CHAIR-01", "name":"Office Chair", "label":"chair", "category":"seating"},
    {"sku":"DEMO-TABLE-01", "name":"Dining Table", "label":"dining table", "category":"tables"},
    {"sku":"DEMO-SOFA-01", "name":"Three-seat Sofa", "label":"couch", "category":"seating"},
    {"sku":"DEMO-BED-01", "name":"Platform Bed", "label":"bed", "category":"bedroom"},
    {"sku":"DEMO-BOOK-01", "name":"Book", "label":"book", "category":"accessories"},
]
BY_SKU = {item["sku"]: item for item in CATALOG}


def match_detections(detections: list[dict]):
    """Map category labels to example products. A category label is NOT an exact SKU match."""
    results = []
    for d in sorted(detections, key=lambda item: -item["confidence"]):
        for item in CATALOG:
            if item["label"] == d["label"]:
                results.append({**item, "confidence": d["confidence"],
                                "bbox": d["bbox"], "match_type": "category_only_not_exact_product"})
    return results
