"""Small event database for chat sessions and *measured* pilot observations."""
from pathlib import Path
import sqlite3
from contextlib import contextmanager


class Store:
    def __init__(self, directory: Path):
        directory.mkdir(exist_ok=True, parents=True)
        self.path = directory / "case2.sqlite3"
        with self.connect() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS sessions(
                    id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, mode TEXT NOT NULL,
                    state TEXT NOT NULL, last_prediction_id TEXT, suggestions_json TEXT NOT NULL DEFAULT '[]',
                    selected_sku TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
                CREATE INDEX IF NOT EXISTS idx_sessions_tenant ON sessions(tenant_id, mode);
                CREATE TABLE IF NOT EXISTS messages(
                    id INTEGER PRIMARY KEY AUTOINCREMENT, session_id TEXT NOT NULL, tenant_id TEXT NOT NULL,
                    role TEXT NOT NULL, message TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
                CREATE TABLE IF NOT EXISTS observations(
                    id INTEGER PRIMARY KEY AUTOINCREMENT, session_id TEXT NOT NULL, tenant_id TEXT NOT NULL,
                    mode TEXT NOT NULL, accepted INTEGER NOT NULL, actual_sku TEXT,
                    manual_minutes REAL, assisted_minutes REAL, cost_usd REAL,
                    error_type TEXT NOT NULL DEFAULT 'unknown', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
            """)

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path, timeout=15)
        db.row_factory = sqlite3.Row
        try:
            yield db
            db.commit()
        finally:
            db.close()
