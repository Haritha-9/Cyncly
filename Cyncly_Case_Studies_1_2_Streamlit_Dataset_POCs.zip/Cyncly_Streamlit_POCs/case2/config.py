from dataclasses import dataclass
from pathlib import Path
import os


@dataclass(frozen=True)
class Settings:
    data_dir: Path
    case1_url: str
    tenant_keys: dict[str,str]
    vlm_enabled: bool
    openai_model: str


def get_settings() -> Settings:
    raw = os.getenv("TENANT_KEYS", "alpha:alpha-demo-key,beta:beta-demo-key")
    return Settings(
        data_dir=Path(os.getenv("DATA_DIR", "./data")).resolve(),
        case1_url=os.getenv("CASE1_URL", "http://127.0.0.1:8001"),
        tenant_keys=dict(part.split(":",1) for part in raw.split(",") if ":" in part),
        vlm_enabled=os.getenv("VLM_ENABLED", "0") == "1",
        openai_model=os.getenv("OPENAI_MODEL", "gpt-4.1-mini"),
    )
