"""Service-to-service adapter, replaceable for unit testing."""
import httpx


class Case1Gateway:
    def __init__(self, base_url: str):
        self.base_url = base_url.rstrip("/")

    async def predict(self, image_bytes: bytes, filename: str, tenant: str, key: str):
        async with httpx.AsyncClient(timeout=90) as client:
            response = await client.post(f"{self.base_url}/v1/predict",
                headers={"X-Tenant-ID": tenant, "X-API-Key": key},
                files={"file": (filename, image_bytes, "application/octet-stream")})
            response.raise_for_status()
            return response.json()
