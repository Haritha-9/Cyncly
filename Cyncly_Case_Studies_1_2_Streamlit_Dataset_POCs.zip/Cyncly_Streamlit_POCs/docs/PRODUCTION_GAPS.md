# Production-readiness gap analysis (what the POC intentionally does NOT claim)

## Case 1

- **Real CV quality:** demo marker identifies only synthetic colors; default examples cannot prove real-world recognition. Generic pretrained YOLO/Faster R-CNN are optional but require testing or fine-tuning for actual product families, occlusion, lighting and small objects.
- **Labeling:** `annotations.csv` shows reviewed flags and a grouped split; production must use controlled annotation tooling, multiple independent reviewers, domain adjudication, versioned taxonomies, and tenant/market coverage audits.
- **Leakage:** SHA/project split guards exact duplicates and projects. Also audit perceptual near-duplicates, shared interiors, sessions, variants and highly similar manufacturer images.
- **Metrics:** basic IoU precision and recall are not COCO mAP; production reports mAP@0.5:0.95, per-class/tenant/occlusion/size slices, confidence calibration, business false positives and false negatives with confidence intervals.
- **Monitoring:** local Prometheus values and an illustrative drift heuristic are not a complete alerting solution. Set real SLOs, service error budgets, aggregated per-customer false negative alerts from audited samples, statistical drift and evidence retention with consent.
- **Security:** static demo keys are not OAuth/OIDC, browser keys are visible, SQLite files are not encrypted, raw logs lack central security review, no rate limiting, retention/deletion/tenant RBAC or fine-grained credentials.
- **Scale:** local files/SQLite, in-process background jobs and a single worker are not enough. Add object storage, DB service, durable queue, image scanning, autoscaling GPU serving, capacity/load tests and idempotent retry semantics.
- **Release:** JSON registry supports canary/rollback demonstration but lacks signed artifacts, a real MLflow registry, automated feature evaluation gates, deployment approvals, rollback scripts linked to infrastructure, or last-good artifacts.
- **Privacy:** don't collect or transmit real customer images in an interview demonstration. Establish consent, tenancy and retention controls for production.

## Case 2

- **Ground truth and business impact:** manual/cv trial data is entered by the user in the POC, not instrumented through a controlled field study. No causal inference or adoption claims are justified.
- **Exact product identity:** object-detection categories alone cannot prove exact SKU, material, dimensions, room compatibility or inventory. Validate with trusted product master data, attributes and user confirmation.
- **Three-option trial:** advanced chatbot is deterministic when VLM is off. A real multimodal model requires explicit enabling, external-data approval, real-cost metrics, safety review and comparative tests.
- **Success gates:** illustrative values (10 feedback per arm, 85% acceptance, 15% faster, zero reported false positives) are placeholders only, not a business sign-off. Agree gates with stakeholders and use representative samples and statistically defensible decisions.
- **99% demand:** never accept a headline '99% accuracy' without defining unit of analysis, severity, class, precision/recall tradeoffs, customer segment and evidence; narrow scope or route uncertain cases to humans.
- **Adoption and trust:** assess user workload, correction burden, product-selection errors and end-user preference in an actual pilot.

## Steps toward a genuine production program

1. Run discovery workshops, baseline measurements and failure-cost analysis.
2. Label a representative, tenant-aware, leakage-free dataset; agree acceptance thresholds and higher-risk classes.
3. Compare YOLO vs Faster R-CNN under identical splits/hardware with mAP, per-customer recall and latency.
4. Conduct shadow-mode pilot followed by assisted mode with explicit human confirmation.
5. Measure user outcomes, error rates, cost, segment drift and operational SLOs.
6. Obtain Product/Domain/Security approval before controlled canary rollout; automate rollback triggers and incident reviews.
