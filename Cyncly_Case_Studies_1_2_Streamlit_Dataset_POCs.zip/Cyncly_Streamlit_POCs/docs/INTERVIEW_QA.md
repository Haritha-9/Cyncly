# Interview Q&A and speaking script (simple English)

The answers refer to what is **actually implemented** in this code, followed by what you would build for production. Do not present the synthetic detector, demo pilot data, or illustrative thresholds as measured business outcomes.

## A two-minute walkthrough

> Case Study 1 is the reusable object-detection platform. It takes a customer image through an authenticated FastAPI endpoint, checks the image quality and metadata, calls a pluggable detection backend, and returns bounding boxes with object categories, confidence scores and the model version. I store prediction records by tenant and expose latency, feedback and basic drift signals. The model registry demonstrates controlled canary release and rollback. In production I would use object storage, a database service, GPU workers, MLflow, a durable queue, real ground-truth evaluation and production-grade monitoring.
>
> Case Study 2 is the business-facing product assistant built **on top of Case Study 1**. I first compare an existing manual process with a CV-assisted pilot. The chatbot can accept an image, show category-level candidates, answer confidence questions, accept corrections, and route uncertain cases to human review. The user must explicitly confirm a proposed catalogue entry. Each session can record time, cost, acceptance and mistakes; a decision API checks whether there is sufficient pilot evidence to consider scaling. I deliberately keep advanced multimodal AI optional because the case study requires an evidence-based decision, not AI adoption for its own sake.

## Case Study 1 — technical design questions

**1. Why separate Case 1 and Case 2 into two services?**  
Case 1 does one technical job: image detection and model operations. Case 2 owns business interactions, chatbot sessions and outcome measurement. Different applications could reuse the same CV API; business changes do not require retraining or redeploying the detector.

**2. What happens when an image arrives?**  
`POST /v1/predict` authenticates the tenant, checks byte length and file content, loads the image with Pillow, fixes EXIF orientation, calculates quality features, chooses a model version, runs detection, stores an image and metadata, and returns JSON boxes, confidence and version.

**3. Why FastAPI?**  
It is simple for Python ML teams, makes REST interfaces and validation easy, and provides an automatically generated Swagger API page. At larger scale the HTTP app should be kept lightweight while dedicated GPU workers do inference.

**4. Why use a detector interface?**  
A common `predict(image)` method lets us replace the simulated marker backend with YOLO or Faster R-CNN without changing routes, storage or chatbot integration. It makes A/B comparison and testing easier.

**5. YOLO versus Faster R-CNN — which would you pick?**  
YOLO is a sensible low-latency starting candidate; Faster R-CNN is a two-stage alternative that can sometimes help complex/small objects but often costs more inference time. I would benchmark both on the **same** tenant-aware frozen test split, at the same resolution/hardware, comparing per-class and per-customer precision, recall, mAP@.5:.95, p95 latency, memory and cost. I would not assume one always wins.

**6. Is the default demo model real AI?**  
No. `MarkerDemoDetector` identifies specific colored regions in specially generated images. It exists to demonstrate a complete API, storage, rollout and chatbot workflow **without an external model download**. Install optional YOLO for generic real-photo detection and then evaluate or fine-tune using relevant product data.

**7. How do you handle lighting, angles and occlusions?**  
Validate image quality, gather diverse real-world images, use label-preserving augmentation, examine small/occluded objects separately, and collect hard negatives. Monitor failure slices by customer rather than relying on only aggregate accuracy. The simple brightness/contrast drift heuristic in this POC illustrates the idea but is not sufficient for production.

**8. How would you prevent training/test leakage?**  
Split by capture/project groups rather than randomly by photo; keep identical images in one split using SHA-256 linking; also audit near-duplicate rooms, shared project sites, bursts and product variants. The included split script protects against cross-project exact duplicate sharing, while more advanced near-duplicate detection is a production next step.

**9. How do you manage imbalanced and rare classes?**  
Report per-class counts; collect more genuine examples from rare and high-risk classes; use controlled oversampling, weighted loss or focal loss where suitable. Evaluate each class with a frozen and representative set; do not inflate test metrics by oversampling the test set.

**10. How do you check annotation quality?**  
Use a written label taxonomy, valid boxes, independent annotation review, agreement/adjudication checks, and versioned corrections. The POC checks valid boxes and a QA flag in a CSV manifest. Real domain review would happen in an annotation tool like CVAT or Label Studio.

**11. What offline metrics matter?**  
mAP@.5:.95, per-class precision/recall, missed-detection count, performance by size/lighting/occlusion, threshold calibration and performance per tenant. This POC's `score_detections.py` computes only IoU=0.5 per-class precision and recall, **not mAP**.

**12. What online metrics matter?**  
Request success and error rate, p50/p95/p99 latency, throughput, GPU utilization, customer-specific acceptance/miss trends, input-resolution/brightness changes, and model/version distribution. The POC implements latency histograms, prediction counts, a user-reported miss proxy, brightness/contrast drift and per-tenant metrics.

**13. How can customer B fail while the aggregate still looks good?**  
If most traffic is from customer A, stable A quality can hide a sudden drop for smaller customer B. I would compare B's recent model version, image properties, label distribution, confidence and ground-truth reviewed false negatives with a previous B baseline and with unaffected tenants. I would segment further by class and camera type and not dismiss the incident because aggregate mAP is stable.

**14. Walk me through a production incident.**  
First establish the impact and recent changes; find request IDs and time window for the affected tenant. Compare input-image drift and model versions, reproduce examples in a secure test environment, check class mappings, preprocessing and threshold shifts, and review labelled false negatives. Roll back or disable the affected rollout if supported by evidence, communicate impact, fix the root cause and add a regression test before redeploying.

**15. How do you deploy and roll back safely?**  
Register immutable versioned artifacts, run dataset/model and latency checks, start a canary on a small stable slice, monitor tenant-level metrics, then gradually promote. In this POC a JSON registry controls active/canary model IDs and keeps rollback history; in production a registry and deployment controller perform signed, audited releases.

**16. Why record the model version with each prediction?**  
It enables incident reproduction, comparison of cohorts, rollback investigation, support requests and feedback-to-training traceability. Without versioning you cannot tell which candidate produced a bad result.

**17. How do you handle bulk uploads?**  
For large work, return a job ID and let a worker process images asynchronously while clients poll status. `POST /v1/jobs` demonstrates this API pattern, but uses in-process FastAPI tasks and is not durable. In production use a real queue, idempotent worker jobs and object-store references.

**18. What tests would you write?**  
Image validation, malformed files, out-of-range sizes, tenant isolation, detector interface mocks, JSON API contract, end-to-end upload, feedback, rollout/rollback, duplicate leakage, box transforms, pilot metrics, model latency/load and drift alerts. There are runnable pytest examples in `tests/`.

**19. How would you scale to hundreds of customers?**  
Separate stateless API replicas from GPU inference pools; use a durable queue for noninteractive work, autoscale by queue depth/latency, cache weights per process, use multi-tenant data access controls, and add rate limits and cost attribution. Review whether shared models or customer-specific adapters make economic sense.

**20. How is personal/customer data secured?**  
In production use OAuth2/OIDC, service identities, least privilege, encryption at rest/in transit, consent, retention/deletion workflows, audit logs and customer-isolated storage. The POC has only static demo API keys and must run on a controlled machine; keys shown in the UI are intentionally not secure.

## Case Study 2 — business, chatbot and product questions

**21. What is the business problem, not just the AI idea?**  
Users spend time manually identifying products from customer images and may choose the wrong catalogue category. The goal is to reduce task time and correction effort while keeping costly mistakes within an agreed risk threshold. First measure the real process instead of assuming AI is needed.

**22. Who are the users?**  
Possible users are design consultants, sales staff, customer support and downstream catalogue/workflow applications. Discovery must verify which real user segment benefits most and what decision the assistant is authorized to influence.

**23. Why implement a chatbot?**  
Object detection alone produces labels and boxes, not a complete business workflow. The chatbot translates that output into a guided conversation, asks for confirmation, handles ambiguous cases, explains limitations and records corrections. It improves usability without making unreviewed purchases or exact SKU claims.

**24. What happens if the detector is wrong?**  
The assistant offers category-based suggestions with uncertainty. The user can say `correct chair`, select another category, or request `human` review. The user's final choice is recorded separately from the model's prediction so errors become feedback for the next evaluation cycle.

**25. Does the chatbot use an LLM?**  
By default no: the session engine is deterministic so reviewers can reproduce every state. The `advanced` option shows a guided UX and optionally uses an external multimodal model for description if explicitly configured. An external description never chooses the catalogue SKU or bypasses human confirmation.

**26. Why not deploy the most advanced multimodal model immediately?**  
The value and failure cost are not yet measured. A more advanced system adds latency, operating cost, privacy requirements and potential hallucinations. Test a manual baseline and conventional CV first; add advanced AI only if controlled evaluation shows extra benefit.

**27. What are the three options?**  
A: catalogue keyword search plus manual human matching; B: object detection, category mapping and chatbot confirmation; C: B plus optional multimodal description/clarification. Compare them on task completion time, acceptance, quality, correction burden, cost and operational risk.

**28. How do you establish a baseline?**  
Observe a representative sample of real manual tasks and record start/end times, error types, corrections and per-task cost. Group by tenant, product and user role; verify that the baseline and pilot have comparable task difficulty. The POC allows entering these observations but does not create valid baseline evidence automatically.

**29. What are reasonable pilot phases?**  
Discovery and data audit → baseline capture → shadow inference → assisted human-in-the-loop pilot → measured go/no-go review → controlled production rollout only if justified. Use explicit exit criteria at every phase and stop if data, quality or privacy are inadequate.

**30. What is the go/no-go criterion?**  
First agree thresholds with Product and risk owners. Illustrative gates might include enough observations in both arms, 85% user acceptance, at least 15% task-time reduction, acceptable false-positive severity and observed per-session cost. The sample endpoint uses these values only to show a decision process, not to certify business readiness.

**31. How do you calculate time saved?**  
Compare observed mean or median duration from a real manual baseline with a comparable assisted cohort. Time saved percent = `(manual_time - assisted_time) / manual_time * 100`. Review confidence intervals, task mix, training effects and correction time; in this POC the estimate is user-supplied and not causal.

**32. False positive versus false negative: which is worse?**  
It depends on the workflow. A wrong product match could cause an incorrect quote/order, so false positives may be expensive. A missed item may require manual search, adding time. Agree costs per error type before choosing a confidence threshold; route high-risk cases to human review.

**33. What if stakeholders insist on 99% accuracy?**  
Ask what "accuracy" means: image-level? object-level recall? precision? exact SKU match? customer-specific? Then show credible evaluation and data uncertainty. If the data cannot support 99%, do not promise it; narrow to a safer product subset, collect better labels, add human review and agree an attainable business KPI with explicit no-go conditions.

**34. How do you prevent hallucinated product matches?**  
Use trusted catalogue records and deterministic SKU mapping; treat detector and VLM outputs as suggestions, not authoritative database facts. Do not generate product identifiers with an LLM. Require user confirmation and route unknown categories to an expert rather than guessing.

**35. What data is stored in the chatbot?**  
Session ID, tenant, option, suggestions, user/assistant messages, confirmed SKU and a single optional observation about time/cost/errors. In production apply retention, consent, encryption and access controls. This example records no real personal identity.

**36. What discovery questions do you ask?**  
Product: where is time lost, what is failure cost, and who owns outcomes? Domain experts: which categories are ambiguous and what is an acceptable match? Data Engineering: are historical images representative, linkable and consented? End users: when do they prefer a suggestion versus a manual choice? The API exposes a checklist at `/v1/pilot/discovery`.

**37. What would make you stop the pilot?**  
Unacceptable wrong-product risk, material customer-specific failures, insufficient/biased data, an unaffordable cost per task, poor user adoption, latency that harms the workflow, or security/privacy requirements that cannot be met. A stop is a valid evidence-based result.

**38. What are the next steps after this POC?**  
Meet stakeholders to define outcomes; create domain-specific ground truth and review rules; benchmark real models; instrument baseline and pilot cohorts; validate tenant-level performance; conduct controlled user studies; secure the APIs, storage and external model options; then decide whether to invest in deployment.

## Five-minute live interview demo script

1. **Minute 1 — problem/architecture.** Explain Case 1 as shared CV service and Case 2 as evidence-based business pilot; show `docs/diagrams/`.
2. **Minute 2 — CV API.** Open `http://127.0.0.1:8001/docs`, upload `data/samples/room.png`, explain preprocessing, response JSON, boxes and version. Say explicitly that colored markers simulate inference offline.
3. **Minute 3 — chatbot.** Open `http://127.0.0.1:8002/`, create a CV pilot session, choose `Room` sample, ask `why confidence`, `correct chair`, `choose 1` or `human`.
4. **Minute 4 — observability and rollout.** Show Case 1 `/v1/analytics/tenant` with separate tenant keys and the registry active/canary controls. Explain why tenant B can fail while global metrics remain stable.
5. **Minute 5 — decision quality.** Record one **illustrative** pilot outcome, show `/v1/pilot/decision` returning `insufficient_evidence`, and explain the real data needed to justify scaling. Finish with key risks: accuracy, exact SKU ground truth, time saved, latency, security and cost.
