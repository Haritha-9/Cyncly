# Streamlit + dataset workflow — Case Studies 1 and 2

## 1. What you will demonstrate

| Browser | Purpose | Code | Backend |
|---|---|---|---|
| **http://127.0.0.1:8501** | **Case Study 1:** upload image, visualize detections and confidence boxes, save feedback, import/validate datasets, retrieve Wikimedia Commons examples, review tenant metrics and model releases | `ui/case1_streamlit.py` | FastAPI Case 1 at `:8001` |
| **http://127.0.0.1:8502** | **Case Study 2:** choose manual/CV/advanced pilot mode, upload images, interact with guided chatbot, confirm catalogue suggestion, record pilot observations and inspect go/no-go decisions | `ui/case2_streamlit.py` | FastAPI Case 2 at `:8002`, which calls Case 1 when images are analyzed |

Both are **demonstration UIs**, not production authentication, exact product recognition or a general-purpose LLM chatbot. The default model recognizes colored rectangles in `data/samples/`, NOT ordinary furniture photos. For real-world detection, optionally activate a downloaded pretrained YOLO adapter via the model-registry controls and use a properly annotated test dataset.

## 2. One-command start (recommended)

From this repository's root directory:

**Windows PowerShell**:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\run_streamlit_windows.ps1
```

**macOS/Linux**:

```bash
bash scripts/run_streamlit.sh
```

**Docker** (with Docker Desktop / Engine installed):

```bash
docker compose up --build
```

Visit `http://127.0.0.1:8501` and `http://127.0.0.1:8502`. Both API docs remain available at `http://127.0.0.1:8001/docs` and `http://127.0.0.1:8002/docs`. Running the first command installs Python dependencies, so **internet access is required for first-time installation**. Wikimedia collection and optional real-model weights also require network access; synthetic marker demos do not after installation.

## 3. Manual start (4 terminals)

```bash
python -m venv .venv
# macOS/Linux: source .venv/bin/activate
# Windows:     .venv\Scripts\activate
python -m pip install -r requirements-ui.txt
python scripts/generate_samples.py
python scripts/import_demo_dataset.py
python -m pytest -q

# Terminal 1
python -m uvicorn case1.main:app --host 127.0.0.1 --port 8001
# Terminal 2
python -m uvicorn case2.main:app --host 127.0.0.1 --port 8002
# Terminal 3
python -m streamlit run ui/case1_streamlit.py --server.port 8501
# Terminal 4
python -m streamlit run ui/case2_streamlit.py --server.port 8502
```

## 4. Dataset import, automated validation and web collection

### A. Offline demonstration dataset (always available)

Choose **Case 1 → Dataset import & validation → Offline sample**. The importer creates `data/demo_import/images_manifest.csv` and `boxes.csv`. The audit checks file integrity and box geometry, and warns that three synthetic images are too small for real accuracy claims.

CLI alternative:

```bash
python scripts/import_demo_dataset.py
python scripts/validate_dataset.py --images data/demo_import/images_manifest.csv --boxes data/demo_import/boxes.csv --strict --report data/demo_import/validation.json
```

### B. Your own reviewed YOLO dataset ZIP

Choose **Case 1 → Dataset import & validation → YOLO ZIP upload**. Expected ZIP folder structure:

```text
dataset/
  data.yaml        # names: [chair, couch, bed, dining table]
  train/images/...
  train/labels/...
  valid/images/...
  valid/labels/...
  test/images/...
  test/labels/...
```

Each YOLO label uses `class_id x_center y_center width height` with normalized coordinates. This UI protects against archive traversal and enforces file/count/size limits. **Only select "human-reviewed annotations" when that statement is genuinely true.** Imported image files and annotations stay local.

CLI alternative:

```bash
python scripts/import_yolo_dataset.py --source path/to/extracted/dataset --output data/real_labeled --tenant alpha
# Add --reviewed ONLY when all boxes were human QA checked.
python scripts/validate_dataset.py --images data/real_labeled/images_manifest.csv --boxes data/real_labeled/boxes.csv --strict
```

### C. Collect a small web-image **visual-test** dataset

Choose **Case 1 → Dataset import & validation → Web-image collection**. Enter a contact email for the User-Agent; select furniture categories and 1–6 images per category. The program uses a restrained Wikimedia Commons API or HTML gallery parser, respects `robots.txt`, rate limits requests, verifies each candidate's media source/license, records attribution and deduplicates selected images.

CLI alternative:

```bash
python scripts/import_demo_dataset.py
python scripts/scrape_test_images.py --contact your-email@example.com --categories Chairs Sofas --per-category 2 --discovery api
# To demonstrate actual HTML gallery scraping instead of API-only discovery:
python scripts/scrape_test_images.py --contact your-email@example.com --categories Chairs Sofas --per-category 2 --discovery html
python scripts/validate_dataset.py --images data/web_test/images_manifest.csv --boxes data/web_test/boxes.csv --strict --report data/web_test/validation.json
```

Outputs: `data/web_test/images/`, `images_manifest.csv`, `boxes.csv` (empty), `CREDITS.md` and `collection_report.json`. Collection depends on live Internet/site availability; failures are reported rather than replaced by fabricated images. Wikimedia Commons images have individual licenses, some of which require attribution or share-alike terms; inspect source pages before use. **Search categories are NOT annotations.** These photos are smoke tests only unless bounding-box truth is independently reviewed.

### D. Optional public object-detection annotations

Open Images V7 has real bounding boxes. A bounded optional example is `scripts/download_openimages_v7.py`. It needs separate `fiftyone` installation and downloads the public subset; this is heavier than the offline POC:

```bash
python -m pip install -r requirements-openimages.txt
python scripts/download_openimages_v7.py --split validation --max-samples 12 --classes Chair Couch Bed
```

Review external dataset license and existing annotation quality, convert/inspect the export, and **keep final test data distinct from training/tuning data**. Do not present third-party labels as independently verified by this project.

## 5. What validation actually checks

- Images open successfully and conform to size/format constraints; recorded SHA-256/dHash match actual files.
- Image brightness/contrast and edge-detail warnings.
- Bounding boxes have numeric coordinates in actual image bounds and a reviewed label where applicable.
- Exact SHA duplicates and likely perceptual duplicates *across* data splits, plus project-level leakage checks.
- Class counts / imbalance, tiny dataset warnings, and missing train/validation/test splits.
- Web test images preserve source URL, original author, and license metadata.

`PASS` means structural QA passed. **It does not mean the model reached business acceptance thresholds.** This synthetic example cannot establish mAP, true customer-specific recall, exact SKU accuracy, or production readiness.

## 6. Interview demo (3 minutes)

1. On `:8501`, select **Detect image** → sample `room.png` → **Detect objects**. Explain the processing sequence and show bounding boxes and JSON confidence.
2. Select **Dataset import & validation** → import synthetic dataset → review warnings; optionally show labeled ZIP upload and a restrained Commons collection.
3. Show **Monitoring** and **Model release** to explain tenant-specific failure detection, canary releases and rollback.
4. On `:8502`, choose **CV + chatbot** → start conversation → upload the same sample → observe catalogue candidates → send `why confidence`, `correct chair`, `choose 1`, or `human`.
5. Navigate to **Pilot feedback & metrics** to demonstrate how a business pilot is measured against a manual baseline, with no invented improvement data.

### Requirement mapping

| Requirement | Demonstration |
|---|---|
| Case 1: API / ingest / preprocessing / inference / predictions | `:8501` image detection connected to `:8001` |
| Case 1: model strategy and trade-offs | Optional YOLO/Faster R-CNN adapter + separate registry controls; compare only on identical labeled data |
| Case 1: annotation, splits, leakage, evaluation | YOLO ZIP import, offline sample, quality validation, warning report |
| Case 1: metrics/drift | `:8501` Monitoring page; Case 1 analytic endpoints |
| Case 1: one-customer missed detections | Per-tenant feedback and drift proxies, not true recall |
| Case 1: Python service design | FastAPI `case1` source and automated tests |
| Case 2: business discovery / options | `:8502` Business options & discovery |
| Case 2: manual → pilot → production decisions | Manual/CV/advanced modes, pilot metrics and gates |
| Case 2: user chatbot + human review | Upload, guided chat, explicit confirmation and escalation |
| Case 2: 99% target with inadequate data | Explain the metric, use reviewed reference data, narrow scope and escalate uncertain cases |
