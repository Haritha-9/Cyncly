# Architecture walkthrough and mapping to the original case-study requirements

## Case 1 — HLD

`Client -> Tenant API -> Image ingestion & quality check -> Pluggable detector -> Bounding-box postprocessing -> Prediction JSON -> Client workflow`.

Cross-cutting: local object storage, metadata DB, customer-specific metrics and feedback. Offline: reviewed dataset -> group-safe splits -> benchmark YOLO/Faster R-CNN -> quality gates -> registry -> canary -> monitored rollback. The default synthetic detector makes the demo runnable offline, but **is not a real model**.

See: `diagrams/Case1_LLD_Runtime.png`, `diagrams/Case1_LLD_Training.png`.

## Case 1 — LLD sequence: `POST /v1/predict`

1. `case1/auth.py` validates demo tenant key; no tenant may request another tenant's prediction.
2. `case1/main.py` reads the file with a byte limit.
3. `case1/images.py` validates actual image bytes, format, minimum/maximum size, normalizes EXIF rotation to RGB PNG, records image quality features and SHA-256.
4. `case1/registry.py` selects the active or canary model using a stable hash bucket, then `case1/detection.py` instantiates the corresponding backend once per worker.
5. The backend predicts objects; the backend is responsible for NMS (YOLO/Faster R-CNN frameworks apply it); the marker demo simply identifies exact palette areas.
6. `case1/storage.py` writes a normalized image to `data/images/<tenant>/<prediction_id>.png` and saves predictions/metadata in a tenant-keyed SQLite table.
7. Prometheus counters and histograms are updated and a JSON payload with boxes, confidence and model version is returned.
8. If requested, `/feedback` records user corrections; `/analytics/tenant` reports acceptance and *reported missed-object rate as proxy, not validated recall*.

**Batch path:** `/v1/jobs` starts an in-process background task and `/v1/jobs/{id}` polls it. This is explicitly *not* a durable production queue.

## Case 2 — HLD

`Discovery -> Manual baseline -> Compare three options -> Small tenant pilot -> Measure impact / risk / cost -> Go/no-go review -> Scale only with evidence`.

Pilot UX flow: `Browser chat -> Case 2 REST API -> Case 1 detection service -> catalogue category lookup -> chatbot questions / correction -> user confirmation or human review -> observed outcome -> pilot metrics`.

See: `diagrams/Case2_HLD.png`, `diagrams/Case2_LLD.png`, `diagrams/Case2_Chatbot.png`.

## Case 2 — LLD sequence: chatbot pilot

1. Browser chooses tenant and `manual`, `cv`, or `advanced`, then `POST /v1/sessions` creates a tenant-isolated record.
2. For `manual` the user types keywords; **no inference request** occurs. This is the rules/manual-assisted baseline.
3. For `cv`/`advanced`, `POST /v1/sessions/{id}/image` calls Case 1 `/v1/predict` with tenant credentials.
4. `case2/catalog.py` maps broad COCO-style labels to mock product categories. A match is not an exact SKU claim.
5. `case2/chat.py` creates a user-facing response, handles `choose 1`, `correct chair`, `why confidence`, `show options`, `human`.
6. The session is only `confirmed` after an explicit choice. Human escalation records `human_review` status without selection.
7. `POST .../feedback` stores an observed time, cost, acceptance and error category, ideally with ground truth supplied by a domain expert.
8. `/v1/pilot/metrics` compares customer-level manual and assisted observations and `/v1/pilot/decision` applies example decision gates. No evidence => `insufficient_evidence`.
9. `advanced` can optionally request an external image description, but the description cannot set a SKU; if disabled it is only an advanced UX simulation.

## Mapping: Case 1 assessment task -> implementation

| Task from brief | PoC code | What's deferred for production |
|---|---|---|
| 1. End-to-end architecture incl. ingestion, validation, preprocessing, API, storage, observability, deployment | `case1/main.py`, `images.py`, `detection.py`, `storage.py`, Docker Compose, metrics | OAuth, S3, PostgreSQL, Kubernetes, centralized tracing |
| 2. Choose and compare object detectors, YOLO vs Faster R-CNN | Pluggable backends in `detection.py`, registry entries, `scripts/benchmark_models.py`, `docs/INTERVIEW_QA.md` | Cost + precision/recall/mAP benchmark on real frozen customer data |
| 3. Splits, imbalance, augmentation, label QA and leakage | `scripts/split_manifest.py`, `augment_demo.py`, `data/annotations.csv` | Stratified group-aware sampling and domain-specialist multiple-review annotation |
| 4. Offline and production metrics, latency, reliability and drift | `scripts/score_detections.py`, `/analytics/tenant`, `/analytics/drift`, Prometheus `/metrics` | Full mAP, confidence calibration, p95 SLO alerting, PSI/embedding drift |
| 5. Investigate customer-specific misses with stable aggregate | Tenant-scoped feedback/metrics; `docs/INTERVIEW_QA.md` runbook | Centralized logs, tracing, formal incident management, verified root cause |
| 6. Python interface / testing | FastAPI interfaces, `Detector` Protocol, `tests/` and `scripts/smoke_test.py` | Load testing, contract testing with production consumers, shadow traffic |

## Mapping: Case 2 assessment task -> implementation

| Task from brief | PoC code | What's deferred for real pilot |
|---|---|---|
| 7. Reframe problem/users/decisions/workflow | `README.md`, chatbot sample, `docs/INTERVIEW_QA.md` | Actual user discovery |
| 8. Discovery questions for Product, Domain, Data Eng and end users | `GET /v1/pilot/discovery` | Interview people, document answers and constraints |
| 9. Phased baseline -> pilot -> production, explicit go/no-go | three modes + `/v1/pilot/decision` | Approved trial protocol, prospective cohorts and representative customers |
| 10. Baseline and success metrics incl. cost and risk | `case2/storage.py`, `/feedback`, `/v1/pilot/metrics` | Independently measured time, cost, error consequences and uncertainty |
| 11. Compare manual/rules vs conventional CV vs advanced AI | `GET /v1/pilot/options`, optional VLM scaffold | Run same controlled evaluation across all options |
| 12. Stakeholder demands 99% unsupported by data | stop/insufficient-evidence gate, Q&A | Negotiated measurable precision/recall target, improved labels / narrowed scope |

## Why every major service / tool exists (simple English)

| Service/tool | Why it is used | Main requirement |
|---|---|---|
| Python | Shared language for APIs, CV adapters and experiment scripts | Case 1 tasks 1, 2, 6; Case 2 tasks 9-11 |
| FastAPI | Typed REST endpoints that apps and the chatbot can call | Case 1 task 1, 6; Case 2 task 9 |
| Uvicorn | Runs the FastAPI HTTP services locally | Case 1 task 1 |
| Pillow | Checks/rotates/resizes image representation and extracts quality data | Case 1 tasks 1, 3, 4 |
| MarkerDemoDetector | Makes a transparent, deterministic, offline flow simulation | PoC demonstration only; **not** model accuracy evidence |
| Ultralytics YOLO | Optional real detection with good low-latency potential | Case 1 tasks 2, 4 |
| Torchvision Faster R-CNN | Optional two-stage comparison candidate | Case 1 tasks 2, 4 |
| SQLite | Lightweight, local tenant-keyed prediction/session/feedback records | Case 1 tasks 1, 4, 5; Case 2 tasks 9, 10 |
| Local image store | Stores normalized images for audit and analysis | Case 1 tasks 1, 5 |
| JSON file registry | Simulates active/canary version rollout and rollback history | Case 1 tasks 1, 5 |
| Prometheus client | Exposes request counts and inference latency histograms | Case 1 task 4 |
| In-process background tasks | Demonstrates an async endpoint and polling pattern | Case 1 task 1 |
| CSV manifests + hashlib | Versionable, verifiable dataset metadata and duplicate grouping | Case 1 task 3 |
| Bounding-box scorer | Calculates per-class precision and recall at IoU 0.5 | Case 1 task 4 |
| Httpx | Makes service-to-service HTTP requests and live smoke test calls | Case 2 tasks 9, 11 |
| Demo catalogue | Shows category mapping while avoiding false claims of exact product ID | Case 2 tasks 7, 11 |
| Guided chatbot engine | Allows clarification, correction, approval and human escalation | Case 2 tasks 7, 11 |
| Browser HTML/JS | Lets interviewer interact with the pilot without a front-end build | Case 2 tasks 7, 9 |
| Optional OpenAI VLM | Adds an image-description experiment, **opt-in only** | Case 2 task 11 |
| Pilot observation DB | Records observed time, acceptance, costs and error type | Case 2 tasks 9, 10 |
| Pilot decision endpoint | Makes evidence thresholds explicit instead of claiming AI success | Case 2 tasks 9, 12 |
| Pytest + TestClient | Tests correctness, tenant separation and flows | Case 1 task 6; Case 2 task 9 |
| Docker / Docker Compose | Reproduces the two-service environment | Case 1 task 1; Case 2 task 9 |
| GitHub Actions YAML | Illustrates an automated test gate on commit | Case 1 task 1 |

**Target production substitutions:** PostgreSQL for SQLite, S3 for local files, Kafka/SQS/RabbitMQ worker queue for BackgroundTasks, MLflow+DVC/lakeFS for registry/data versions, K8s with GPU nodes for scaled inference, OAuth2/OIDC and a central observability stack. The PoC does **not** claim these external services are deployed.
