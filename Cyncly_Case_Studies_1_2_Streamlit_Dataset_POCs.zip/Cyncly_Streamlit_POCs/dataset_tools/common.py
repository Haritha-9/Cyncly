"""Standardized dataset schemas, image fingerprints, metadata, and IO.

Do not infer object detection ground truth from an image category or a web search.
Images become labeled only after a human has reviewed bounding boxes.
"""
from __future__ import annotations
from dataclasses import dataclass
from io import BytesIO
from pathlib import Path
import csv
import hashlib
import re

from PIL import Image, ImageOps, ImageStat, ImageFilter, UnidentifiedImageError

Image.MAX_IMAGE_PIXELS = 36_000_000

IMAGE_FIELDS = [
    "image_id", "split", "tenant_id", "project_id", "image_path", "sha256",
    "dhash", "width", "height", "brightness", "contrast", "edge_variance",
    "annotation_status", "source", "source_url", "license", "license_url", "author", "category_hint",
]
BOX_FIELDS = ["image_id", "label", "x1", "y1", "x2", "y2", "reviewed"]
ALLOWED_EXT = {".jpg", ".jpeg", ".png", ".webp"}


def safe_token(text: str, limit: int = 70) -> str:
    value = re.sub(r"[^a-zA-Z0-9._-]+", "_", str(text)).strip("._-")
    return (value or "item")[:limit]


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def dhash(image: Image.Image) -> str:
    """64-bit difference hash to detect likely near-duplicate images."""
    gray = ImageOps.grayscale(image).resize((9, 8))
    pix = list(gray.get_flattened_data() if hasattr(gray, "get_flattened_data") else gray.getdata())
    value = 0
    for y in range(8):
        for x in range(8):
            value = (value << 1) | int(pix[y*9+x] > pix[y*9+x+1])
    return f"{value:016x}"


def hash_distance(a: str, b: str) -> int:
    return (int(a, 16) ^ int(b, 16)).bit_count()


def inspect_image(path: Path, max_bytes: int = 10_000_000) -> dict:
    if path.stat().st_size > max_bytes:
        raise ValueError("File is larger than allowed size")
    try:
        with Image.open(path) as im:
            if im.format not in {"JPEG", "PNG", "WEBP"}:
                raise ValueError("Unsupported actual image format")
            im.verify()
        with Image.open(path) as im:
            image = ImageOps.exif_transpose(im).convert("RGB")
            if min(image.size) < 64 or max(image.size) > 8000:
                raise ValueError("Image outside 64..8000 pixel edge range")
            g = ImageOps.grayscale(image)
            s = ImageStat.Stat(g)
            edge = g.filter(ImageFilter.FIND_EDGES)
            return {
                "sha256": sha256_file(path), "dhash": dhash(image),
                "width": image.width, "height": image.height,
                "brightness": round(s.mean[0], 2), "contrast": round(s.stddev[0], 2),
                "edge_variance": round(ImageStat.Stat(edge).var[0], 2),
            }
    except (UnidentifiedImageError, OSError, Image.DecompressionBombError) as exc:
        raise ValueError(f"Unreadable image ({type(exc).__name__})") from exc


def make_image_row(path: Path, image_id: str, split: str,
                   tenant: str, project_id: str, status: str, source: str,
                   source_url: str = "", license_name: str = "", license_url: str = "",
                   author: str = "", category_hint: str = "") -> dict:
    info = inspect_image(path)
    return {
        "image_id": image_id, "split": split, "tenant_id": tenant,
        "project_id": project_id, "image_path": str(path),
        **info, "annotation_status": status, "source": source,
        "source_url": source_url, "license": license_name,
        "license_url": license_url, "author": author,
        "category_hint": category_hint,
    }


def write_csv(path: Path, rows: list[dict], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)


def read_csv(path: Path) -> list[dict]:
    with path.open("r", newline="", encoding="utf-8") as fh:
        return list(csv.DictReader(fh))
