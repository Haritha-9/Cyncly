# Windows PowerShell. Start four services and stop with Ctrl+C.
$ErrorActionPreference = 'Stop'
Set-Location (Join-Path $PSScriptRoot '..')
if (-not (Test-Path '.venv\Scripts\python.exe')) { py -3 -m venv .venv }
$python = (Resolve-Path '.venv\Scripts\python.exe').Path
& $python -m pip install -r requirements-ui.txt
if ($LASTEXITCODE -ne 0) { throw 'Package installation failed' }
& $python scripts/generate_samples.py
& $python scripts/import_demo_dataset.py
$env:CASE1_URL = 'http://127.0.0.1:8001'
$env:CASE2_URL = 'http://127.0.0.1:8002'
$env:STREAMLIT_BROWSER_GATHER_USAGE_STATS = 'false'
$running = @()
try {
    $running += Start-Process -FilePath $python -ArgumentList '-m','uvicorn','case1.main:app','--host','127.0.0.1','--port','8001' -PassThru
    $running += Start-Process -FilePath $python -ArgumentList '-m','uvicorn','case2.main:app','--host','127.0.0.1','--port','8002' -PassThru
    $running += Start-Process -FilePath $python -ArgumentList '-m','streamlit','run','ui/case1_streamlit.py','--server.headless','true','--server.address','127.0.0.1','--server.port','8501' -PassThru
    $running += Start-Process -FilePath $python -ArgumentList '-m','streamlit','run','ui/case2_streamlit.py','--server.headless','true','--server.address','127.0.0.1','--server.port','8502' -PassThru
    Write-Host 'Case 1 Streamlit: http://127.0.0.1:8501'
    Write-Host 'Case 2 Streamlit: http://127.0.0.1:8502'
    Write-Host 'APIs: http://127.0.0.1:8001/docs and http://127.0.0.1:8002/docs'
    Write-Host 'Press Ctrl+C to stop the services.'
    while ($true) { Start-Sleep -Seconds 2 }
} finally {
    foreach ($p in $running) {
       if ($p -and -not $p.HasExited) { Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue }
    }
}
