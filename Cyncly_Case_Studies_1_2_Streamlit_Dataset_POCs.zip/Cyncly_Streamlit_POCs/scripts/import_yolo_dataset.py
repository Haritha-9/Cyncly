"""Import any *licensed/authorized* labeled YOLO dataset into unified schema.

Expected:
  SOURCE/data.yaml  (names: [chair, couch, ...])
  SOURCE/train/images/xx.jpg and SOURCE/train/labels/xx.txt
  SOURCE/valid/images/xx.jpg and SOURCE/valid/labels/xx.txt
  SOURCE/test/images/xx.jpg and SOURCE/test/labels/xx.txt

YOLO annotation format per line: class_id x_center y_center width height (normalized).
No file is silently considered reviewed: specify --reviewed only for human-QA'd labels.
"""
import argparse
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from dataset_tools.common import (IMAGE_FIELDS, BOX_FIELDS, ALLOWED_EXT,
                                  make_image_row, safe_token, write_csv)


def parse_yolo_box(text: str, labels: list[str], imw: int, imh: int) -> dict:
    vals = text.split()
    if len(vals) != 5:
        raise ValueError("YOLO line needs class x_center y_center width height")
    class_id = int(vals[0]); cx, cy, w, h = map(float, vals[1:])
    if class_id < 0 or class_id >= len(labels) or not all(0 <= v <= 1 for v in (cx,cy,w,h)):
        raise ValueError("Invalid class ID or coordinates outside [0,1]")
    if not (w > 0 and h > 0 and 0 <= cx - w/2 and cx + w/2 <= 1.000001 and
            0 <= cy - h/2 and cy + h/2 <= 1.000001):
        raise ValueError("Bounding box outside image")
    x1,x2 = (cx - w/2)*imw, (cx + w/2)*imw
    y1,y2 = (cy - h/2)*imh, (cy + h/2)*imh
    return {"label": labels[class_id], "x1":round(x1,2), "y1":round(y1,2),
            "x2":round(x2,2), "y2":round(y2,2)}


def import_dataset(source: Path, output: Path, tenant: str, reviewed: bool,
                   class_names: list[str] | None = None) -> dict:
    if class_names is None:
        try:
            import yaml
        except ImportError as exc:
            raise RuntimeError("Install requirements-datasets.txt to parse data.yaml") from exc
        metadata = yaml.safe_load((source / "data.yaml").read_text(encoding="utf-8"))
        names = metadata["names"]
        class_names = [names[i] for i in sorted(names)] if isinstance(names, dict) else list(names)
    images, boxes = [], []
    for src_split, target_split in [("train","train"), ("valid","val"), ("val","val"), ("test","test")]:
        root = source / src_split / "images"
        if not root.exists():
            continue
        for path in sorted(root.rglob("*")):
            if not path.is_file() or path.suffix.lower() not in ALLOWED_EXT:
                continue
            rel = path.relative_to(root)
            image_id = safe_token(f"{src_split}_{rel.stem}_{__import__('hashlib').sha256(str(rel).encode()).hexdigest()[:9]}")
            dest = output / "images" / target_split / f"{image_id}{path.suffix.lower()}"
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, dest)
            info = make_image_row(dest, image_id, target_split, tenant,
                                  rel.parent.as_posix() if rel.parent != Path('.') else image_id,
                                  "reviewed" if reviewed else "unlabeled",
                                  "yolo_import")
            images.append(info)
            label_file = source / src_split / "labels" / rel.with_suffix(".txt")
            if not reviewed:
                # Keeping unverified label files out of ground truth is deliberate.
                continue
            if not label_file.exists():
                raise ValueError(f"Missing annotation file (include empty .txt for negatives): {label_file}")
            for n, line in enumerate(label_file.read_text(encoding="utf-8").splitlines(),1):
                if not line.strip(): continue
                try:
                    box = parse_yolo_box(line, class_names, int(info["width"]), int(info["height"]))
                except (ValueError, TypeError) as exc:
                    raise ValueError(f"Bad label at {label_file}:{n} ({exc})") from exc
                boxes.append({"image_id":image_id, **box, "reviewed":"yes"})
    if not images:
        raise ValueError("No images found under train/valid/test images folders")
    write_csv(output / "images_manifest.csv", images, IMAGE_FIELDS)
    write_csv(output / "boxes.csv", boxes, BOX_FIELDS)
    return {"images":len(images), "boxes":len(boxes), "output":str(output),
            "human_review_confirmed": reviewed}


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--source",type=Path,required=True)
    parser.add_argument("--output",type=Path,default=Path("data/real_labeled"))
    parser.add_argument("--tenant",default="public-reference")
    parser.add_argument("--reviewed",action="store_true",help="I confirm ALL boxes were human quality-checked")
    a=parser.parse_args()
    print(import_dataset(a.source,a.output,a.tenant,a.reviewed))
    if not a.reviewed:
        print("No ground truth imported without --reviewed; annotate/review labels before accuracy scoring.")

if __name__=="__main__": main()
