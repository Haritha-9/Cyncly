"""Minimal labeled-box evaluator. Computes IoU=.50 precision/recall, NOT mAP.
Inputs are JSON arrays: [{"image_id":"...","detections":[{"label":...,"bbox":[x1,y1,x2,y2]}]}]
Usage: python scripts/score_detections.py --truth data/eval_truth.json --pred data/eval_pred.json
"""
import argparse
import json
from collections import defaultdict


def iou(a,b):
    ix=max(0,min(a[2],b[2])-max(a[0],b[0]))
    iy=max(0,min(a[3],b[3])-max(a[1],b[1]))
    inter=ix*iy
    union=max(0,a[2]-a[0])*max(0,a[3]-a[1])+max(0,b[2]-b[0])*max(0,b[3]-b[1])-inter
    return inter/union if union else 0


def score(truth,pred,threshold=.5):
    actual={row["image_id"]:row.get("detections",[]) for row in truth}
    predicted={row["image_id"]:row.get("detections",[]) for row in pred}
    classes=defaultdict(lambda:{"tp":0,"fp":0,"fn":0})
    for image_id in set(actual)|set(predicted):
        gt=actual.get(image_id,[])
        guesses=sorted(predicted.get(image_id,[]),key=lambda d:-d.get("confidence",1))
        taken=set()
        for g in guesses:
            best_index=None;best_iou=0
            for i,t in enumerate(gt):
                if i not in taken and g["label"]==t["label"]:
                    overlap=iou(g["bbox"],t["bbox"])
                    if overlap>best_iou:
                        best_iou,best_index=overlap,i
            if best_index is not None and best_iou>=threshold:
                classes[g["label"]]["tp"]+=1
                taken.add(best_index)
            else:
                classes[g["label"]]["fp"]+=1
        for i,t in enumerate(gt):
            if i not in taken:classes[t["label"]]["fn"]+=1
    result={}
    for label,c in sorted(classes.items()):
        p=c["tp"]/(c["tp"]+c["fp"]) if c["tp"]+c["fp"] else None
        r=c["tp"]/(c["tp"]+c["fn"]) if c["tp"]+c["fn"] else None
        result[label]={**c,"precision":round(p,3) if p is not None else None,
                        "recall":round(r,3) if r is not None else None}
    return result

if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--truth",required=True);parser.add_argument("--pred",required=True)
    args=parser.parse_args()
    with open(args.truth) as f: gt=json.load(f)
    with open(args.pred) as f: pr=json.load(f)
    print(json.dumps({"IoU_0.5_per_class":score(gt,pr),"warning":"Not mAP; evaluate real models with COCOeval and a frozen dataset."},indent=2))
