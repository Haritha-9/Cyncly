"""Dataset audit: integrity, annotations, cross-split leakage, and quality.

Example:
 python scripts/validate_dataset.py --images data/demo_import/images_manifest.csv --boxes data/demo_import/boxes.csv
 python scripts/validate_dataset.py --images data/web_test/images_manifest.csv --boxes data/web_test/boxes.csv

Web-collected unlabeled images can be audited for quality, but NOT scored for detection recall.
"""
import argparse
from collections import Counter, defaultdict
from pathlib import Path
from PIL import Image
import json
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from dataset_tools.common import read_csv, inspect_image, hash_distance


def validate_dataset(images: list[dict], boxes: list[dict], base_dir: Path,
                     near_threshold: int = 4) -> dict:
    errors, warnings = [], []
    ids = set()
    filepaths = {}
    per_split = Counter()
    per_class = Counter()
    sha_groups = defaultdict(set)
    perceptual = []
    project_groups = defaultdict(set)
    labeled_ids = set()
    web_unlabeled = 0

    for row_no, row in enumerate(images, 2):
        image_id = row.get("image_id", "")
        if not image_id or image_id in ids:
            errors.append(f"images line {row_no}: blank or repeated image_id {image_id!r}")
        ids.add(image_id)
        split = row.get("split", "")
        if split not in {"train", "val", "test", "web_test"}:
            errors.append(f"{image_id}: unknown split {split!r}")
        per_split[split] += 1
        path = Path(row.get("image_path", ""))
        if not path.is_absolute():
            # Most generated manifests contain paths relative to project root;
            # if a manifest is moved, the caller can specify --base-dir.
            path = base_dir / path
        filepaths[image_id] = path
        if not path.is_file():
            errors.append(f"{image_id}: image missing: {path}")
            continue
        try:
            fresh = inspect_image(path)
        except ValueError as exc:
            errors.append(f"{image_id}: {exc}")
            continue
        if fresh["sha256"] != row.get("sha256"):
            errors.append(f"{image_id}: SHA-256 does not match file (changed after importing)")
        if row.get("dhash") and fresh["dhash"] != row.get("dhash"):
            errors.append(f"{image_id}: perceptual hash does not match file")
        if fresh["brightness"] < 30 or fresh["brightness"] > 230:
            warnings.append(f"{image_id}: extreme brightness; review visibility")
        if fresh["contrast"] < 15:
            warnings.append(f"{image_id}: low contrast; review visibility")
        if fresh["edge_variance"] < 6:
            warnings.append(f"{image_id}: low edge detail; review blur/focus")
        sha_groups[fresh["sha256"]].add(split)
        perceptual.append((image_id, split, fresh["dhash"]))
        tenant_project = (row.get("tenant_id"), row.get("project_id"))
        if split != "web_test" and all(tenant_project):
            project_groups[tenant_project].add(split)
        status = row.get("annotation_status", "")
        if status == "reviewed":
            labeled_ids.add(image_id)
        elif status not in {"unlabeled", "demo_only"}:
            errors.append(f"{image_id}: unknown annotation_status {status!r}")
        if split == "web_test":
            web_unlabeled += status == "unlabeled"
            if status != "unlabeled" and not any(b.get("image_id") == image_id for b in boxes):
                errors.append(f"{image_id}: claimed labeled web test lacks reviewed boxes")
            if not row.get("license") or not row.get("source_url"):
                errors.append(f"{image_id}: web image missing license/source traceability")

    for sha, splits in sha_groups.items():
        if len(splits) > 1:
            errors.append(f"Exact image data leakage across splits: SHA {sha[:12]} in {sorted(splits)}")
    for group, splits in project_groups.items():
        if len(splits) > 1:
            errors.append(f"Project leakage: {group} appears in {sorted(splits)}")
    for i, (a_id, a_split, a_hash) in enumerate(perceptual):
        for b_id, b_split, b_hash in perceptual[i + 1:]:
            if a_split != b_split and hash_distance(a_hash, b_hash) <= near_threshold:
                # Flags may include same-looking product packshots; manual confirmation required.
                warnings.append(f"Possible near-duplicate across splits: {a_id} ({a_split}) vs {b_id} ({b_split})")

    boxes_by_id = defaultdict(int)
    for row_no, box in enumerate(boxes, 2):
        image_id = box.get("image_id", "")
        if image_id not in ids:
            errors.append(f"boxes line {row_no}: image_id not in manifest: {image_id}")
            continue
        if image_id not in labeled_ids:
            errors.append(f"{image_id}: box supplied without annotation_status=reviewed")
        if box.get("reviewed") != "yes":
            errors.append(f"boxes line {row_no}: box lacks reviewer sign-off")
        label = box.get("label", "").strip()
        if not label:
            errors.append(f"boxes line {row_no}: blank category")
        per_class[label] += 1
        boxes_by_id[image_id] += 1
        try:
            coords = [float(box[k]) for k in ("x1", "y1", "x2", "y2")]
            # Validate against actual image dimensions rather than a guessed scale.
            with Image.open(filepaths[image_id]) as im:
                width, height = im.size
            if not (0 <= coords[0] < coords[2] <= width and 0 <= coords[1] < coords[3] <= height):
                errors.append(f"boxes line {row_no}: invalid or out-of-image bounding box")
        except (KeyError, ValueError, OSError):
            errors.append(f"boxes line {row_no}: unreadable/non-numeric bounding box")

    if any(row.get("annotation_status") == "reviewed" for row in images) and not boxes:
        warnings.append("All reviewed images have zero boxes; verify that negatives are intentional")
    for c, count in per_class.items():
        if count < 3:
            warnings.append(f"Class {c!r} has only {count} labeled boxes; imbalance/small sample warning")
    if per_split.get("train") and (not per_split.get("val") or not per_split.get("test")):
        warnings.append("Labeled evaluation needs independent validation and test splits")
    if len(images) < 30:
        warnings.append("Tiny dataset: NOT enough to justify accuracy or scale claims")

    return {
        "status": "PASS" if not errors else "FAIL",
        "counts": {"images": len(images), "boxes": len(boxes),
                   "per_split": dict(per_split), "per_class": dict(per_class),
                   "unlabeled_web_test_images": web_unlabeled},
        "errors": errors, "warnings": list(dict.fromkeys(warnings)),
        "important": "Web-scraped unlabeled images are for visual smoke testing only; compute precision/recall/mAP solely on human-reviewed, frozen bounding-box ground truth.",
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--images", required=True)
    p.add_argument("--boxes", default="")
    p.add_argument("--base-dir", default=".")
    p.add_argument("--report", default="data/dataset_validation_report.json")
    p.add_argument("--strict", action="store_true", help="Exit 1 on errors; default exits 0 for convenient audit")
    p.add_argument("--near-threshold", type=int, default=4)
    a = p.parse_args()
    images = read_csv(Path(a.images))
    boxes = read_csv(Path(a.boxes)) if a.boxes and Path(a.boxes).exists() else []
    report = validate_dataset(images, boxes, Path(a.base_dir), a.near_threshold)
    Path(a.report).parent.mkdir(parents=True, exist_ok=True)
    Path(a.report).write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    print("Wrote report:", a.report)
    if a.strict and report["errors"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
