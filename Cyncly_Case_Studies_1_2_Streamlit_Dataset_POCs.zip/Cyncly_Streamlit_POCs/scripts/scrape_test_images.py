"""Small, respectful furniture image collector for a HELD-OUT, UNLABELED test pool.

Sources: Wikimedia Commons public category pages (HTML mode) / MediaWiki image API
(API mode). Media rights and thumbnails are resolved via the official Imageinfo API.
No unauthorized domains or unrestricted user-supplied URLs are fetched.

Examples:
 python scripts/scrape_test_images.py --contact 'your-email@example.com' --per-category 3
 python scripts/scrape_test_images.py --contact 'your-email@example.com' --discovery html --categories Chairs Sofas

IMPORTANT: category membership is only a search hint, NOT a detection ground-truth label.
Human review with actual bounding boxes is required to compute accuracy.
"""
from __future__ import annotations
import argparse
from collections import Counter
from html import unescape
from io import BytesIO
import json
from pathlib import Path
import sys
import time
from urllib.parse import quote, urlsplit
from urllib.robotparser import RobotFileParser

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from dataset_tools.common import (IMAGE_FIELDS, BOX_FIELDS, make_image_row,
                                  hash_distance, read_csv, safe_token, write_csv)

try:
    import requests
    from bs4 import BeautifulSoup
    from PIL import Image, ImageOps
except ImportError as exc:
    raise SystemExit("Install: python -m pip install -r requirements-datasets.txt") from exc

API = "https://commons.wikimedia.org/w/api.php"
COMMONS = "https://commons.wikimedia.org"
CATEGORIES = ["Chairs", "Sofas", "Dining_tables", "Beds"]
IMAGE_HOSTS = {"upload.wikimedia.org", "thumb.wikimedia.org"}
PAGE_HOST = "commons.wikimedia.org"


def clean_html(v: str) -> str:
    raw = unescape(v or "")
    if "<" not in raw:
        return raw.strip()
    return BeautifulSoup(raw, "html.parser").get_text(" ", strip=True)


def is_allowed_license(ext: dict) -> bool:
    name = clean_html(ext.get("LicenseShortName", {}).get("value", "")).lower().replace(" ", "").replace("-", "")
    # Attribution/ShareAlike obligations remain; we save attribution metadata.
    return name.startswith("ccby") or name.startswith("cc0") or name in {
        "publicdomain", "pd", "pdm", "cc-zero", "publicdomainmark"
    }


def parse_gallery_files(html: str) -> list[str]:
    """HTML scraping: extract file titles from gallery links on category pages."""
    soup = BeautifulSoup(html, "html.parser")
    results = []
    for link in soup.select(".gallerytext a[href], .gallerybox a[href]"):
        href = link.get("href", "")
        if "/wiki/File:" in href:
            title = unescape(href.split("/wiki/", 1)[-1].split("#", 1)[0])
            from urllib.parse import unquote
            title = unquote(title).replace("_", " ")
            if title not in results:
                results.append(title)
    return results


def metadata_from_page(page: dict) -> dict | None:
    title = page.get("title", "")
    if not title.startswith("File:"):
        return None
    info = (page.get("imageinfo") or [{}])[0]
    if info.get("mime") not in {"image/jpeg", "image/png", "image/webp"}:
        return None
    ext = info.get("extmetadata", {})
    if not is_allowed_license(ext):
        return None
    url = info.get("thumburl") or info.get("url", "")
    if urlsplit(url).scheme != "https" or urlsplit(url).hostname not in IMAGE_HOSTS:
        return None
    return {
        "title": title, "image_url": url,
        "source_url": f"{COMMONS}/wiki/{quote(title.replace(' ', '_'), safe=':()_-')}",
        "license": clean_html(ext.get("LicenseShortName", {}).get("value", "")),
        "license_url": clean_html(ext.get("LicenseUrl", {}).get("value", "")),
        "author": clean_html(ext.get("Artist", {}).get("value", "")) or "See original Wikimedia Commons file page",
    }


class CommonsClient:
    def __init__(self, contact: str, delay: float = 1.5, timeout: float = 20):
        if "@" not in contact and "https://" not in contact:
            raise ValueError("Pass a valid contact email or https URL for the User-Agent")
        self.session = requests.Session()
        self.user_agent = f"Cyncly-CaseStudies-POC/1.0 (educational furniture dataset; contact: {contact})"
        self.session.headers["User-Agent"] = self.user_agent
        self.delay = delay
        self.timeout = timeout
        self.robots = {}

    def can_fetch(self, url: str) -> bool:
        host = urlsplit(url).hostname or ""
        if host not in IMAGE_HOSTS | {PAGE_HOST}:
            return False
        if host not in self.robots:
            # Fail closed if permissions cannot be checked. Check both API and image hosts.
            try:
                response = self.session.get(f"https://{host}/robots.txt", timeout=self.timeout)
                response.raise_for_status()
                rp = RobotFileParser()
                rp.parse(response.text.splitlines())
                self.robots[host] = rp
            except requests.RequestException as exc:
                raise RuntimeError(f"Could not verify {host}/robots.txt; refusing to scrape") from exc
        return self.robots[host].can_fetch(self.user_agent, url)

    def get(self, url: str, **kwargs):
        if not self.can_fetch(url):
            raise PermissionError(f"robots.txt prohibits fetching {url}")
        resp = self.session.get(url, timeout=self.timeout, allow_redirects=False, **kwargs)
        resp.raise_for_status()
        time.sleep(self.delay)
        return resp

    def api_pages(self, category: str, max_pages: int = 3) -> list[dict]:
        pages = []
        continuation = None
        for _ in range(max_pages):
            params = {"action":"query", "generator":"categorymembers", "gcmtitle": f"Category:{category}",
                      "gcmtype":"file", "gcmlimit": "50", "prop":"imageinfo",
                      "iiprop":"url|size|mime|extmetadata", "iiurlwidth":"800", "format":"json", "formatversion":"2"}
            if continuation:
                params["gcmcontinue"] = continuation
            content = self.get(API, params=params).json()
            pages.extend(content.get("query", {}).get("pages", []))
            continuation = content.get("continue", {}).get("gcmcontinue")
            if not continuation:
                break
        return pages

    def html_pages(self, category: str, max_pages: int = 1) -> list[dict]:
        # HTML discovery with BeautifulSoup, then metadata verified via imageinfo API.
        # Only one gallery page is used in this small controlled POC.
        url = f"{COMMONS}/wiki/Category:{category}"
        titles = parse_gallery_files(self.get(url).text)[:80]
        pages = []
        for offset in range(0, len(titles), 20):
            data = self.get(API, params={"action":"query", "titles":"|".join(titles[offset:offset+20]),
                         "prop":"imageinfo", "iiprop":"url|size|mime|extmetadata", "iiurlwidth":"800",
                         "format":"json", "formatversion":"2"}).json()
            pages.extend(data.get("query", {}).get("pages", []))
        return pages

    def download_image(self, meta: dict, target: Path, max_bytes: int = 6_000_000) -> None:
        url = meta["image_url"]
        response = self.get(url, stream=True)
        try:
            if "image" not in response.headers.get("Content-Type", ""):
                raise ValueError("Media server did not return an image")
            data = bytearray()
            for chunk in response.iter_content(65536):
                data.extend(chunk)
                if len(data) > max_bytes:
                    raise ValueError("Downloaded file exceeds safe size limit")
            with Image.open(BytesIO(data)) as im:
                if im.format not in {"JPEG", "PNG", "WEBP"}:
                    raise ValueError("Unsupported image format")
                im.verify()
            with Image.open(BytesIO(data)) as im:
                normalized = ImageOps.exif_transpose(im).convert("RGB")
                if min(normalized.size) < 64 or max(normalized.size) > 8000:
                    raise ValueError("Unsupported image dimensions")
                target.parent.mkdir(parents=True, exist_ok=True)
                # Save a normalized JPEG without EXIF, but preserve licensing in manifest.
                normalized.save(target, format="JPEG", quality=90, optimize=True)
        finally:
            response.close()


def collect(client: CommonsClient, output: Path, categories: list[str],
            per_category: int, discovery: str = "api", max_pages: int = 2,
            existing: list[dict] | None = None) -> dict:
    images = []
    seen = set(r.get("sha256") for r in (existing or []))
    known_hashes = [(r.get("dhash", ""), r.get("split", "")) for r in (existing or [])]
    rejects = Counter()
    for category in categories:
        pages = client.api_pages(category, max_pages) if discovery == "api" else client.html_pages(category, max_pages)
        count = 0
        for page in pages:
            if count >= per_category:
                break
            meta = metadata_from_page(page)
            if not meta:
                rejects["nonimage_license_or_domain"] += 1
                continue
            imgid = safe_token(f"web_{category}_{page.get('pageid', meta['title'])}")
            path = output / "images" / f"{imgid}.jpg"
            try:
                client.download_image(meta, path)
                row = make_image_row(path, imgid, "web_test", "public-reference",
                                     f"commons_{category}", "unlabeled", "wikimedia_commons_web_collection",
                                     meta["source_url"], meta["license"], meta["license_url"],
                                     meta["author"], category.replace("_", " "))
                if row["sha256"] in seen:
                    path.unlink(missing_ok=True)
                    rejects["sha_duplicate"] += 1
                    continue
                # Near duplicates crossing from labeled reference sets must be excluded.
                if any(h and hash_distance(row["dhash"], h) <= 4 for h, split in known_hashes if split != "web_test"):
                    path.unlink(missing_ok=True)
                    rejects["possible_near_duplicate_against_labeled_data"] += 1
                    continue
                images.append(row)
                seen.add(row["sha256"])
                known_hashes.append((row["dhash"], "web_test"))
                count += 1
            except (ValueError, OSError, requests.RequestException, PermissionError) as exc:
                path.unlink(missing_ok=True)
                rejects[f"download_or_quality_error_{type(exc).__name__}"] += 1
        if count < per_category:
            print(f"Warning: {category}: got {count}/{per_category} eligible photos; licensing/quality filters apply")
    write_csv(output / "images_manifest.csv", images, IMAGE_FIELDS)
    write_csv(output / "boxes.csv", [], BOX_FIELDS)
    lines = ["# Image credits (Wikimedia Commons)", "", "Images are individually licensed; check the original file pages before reuse.", ""]
    for row in images:
        lines.append(f"- **{row['image_id']}** — {row['author']} — {row['license']} — {row['license_url']} — {row['source_url']} — normalized JPEG (EXIF removed)")
    (output / "CREDITS.md").write_text("\n".join(lines), encoding="utf-8")
    result = {"images_collected":len(images), "counts_by_category":dict(Counter(r["category_hint"] for r in images)),
              "rejected":dict(rejects), "dataset":str(output),
              "warning":"UNLABELED visual test pool; do not use as mAP/accuracy ground truth."}
    (output / "collection_report.json").write_text(json.dumps(result, indent=2),encoding="utf-8")
    return result


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--contact", required=True, help="Your contact email or project URL, sent only in Wikimedia requests User-Agent")
    p.add_argument("--output", type=Path, default=Path("data/web_test"))
    p.add_argument("--categories", nargs="+", default=CATEGORIES)
    p.add_argument("--per-category", type=int, default=3)
    p.add_argument("--max-pages", type=int, default=2)
    p.add_argument("--discovery", choices=["api", "html"], default="api", help="HTML mode uses BeautifulSoup gallery scraping")
    p.add_argument("--delay", type=float, default=1.5)
    p.add_argument("--existing-manifest", type=Path, default=Path("data/demo_import/images_manifest.csv"))
    a = p.parse_args()
    if not (1 <= a.per_category <= 12 and 1 <= a.max_pages <= 4 and a.delay >= 1.0):
        p.error("For responsible collection use 1-12 images per category, 1-4 pages and >=1s delay")
    client = CommonsClient(a.contact, a.delay)
    existing = read_csv(a.existing_manifest) if a.existing_manifest.exists() else []
    print(json.dumps(collect(client, a.output, a.categories, a.per_category,
                             a.discovery, a.max_pages, existing), indent=2))

if __name__ == "__main__":
    main()
