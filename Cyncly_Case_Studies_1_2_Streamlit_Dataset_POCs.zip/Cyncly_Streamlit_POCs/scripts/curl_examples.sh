#!/usr/bin/env bash
# Run after starting both services. Execute from the project root.
set -euo pipefail
H1='X-Tenant-ID: alpha'; H2='X-API-Key: alpha-demo-key'
BASE1='http://127.0.0.1:8001'; BASE2='http://127.0.0.1:8002'
echo 'CASE 1 image inference'
curl -sS -X POST "$BASE1/v1/predict" -H "$H1" -H "$H2" -F 'file=@data/samples/room.png' | python -m json.tool
echo 'CASE 1 customer analytics'
curl -sS "$BASE1/v1/analytics/tenant" -H "$H1" -H "$H2" | python -m json.tool
echo 'CASE 1 deployment versions'
curl -sS "$BASE1/v1/admin/models" -H 'X-Admin-Key: local-admin-demo-key' | python -m json.tool
echo 'CASE 2 available options'
curl -sS "$BASE2/v1/pilot/options" | python -m json.tool
echo 'CASE 2 start session'
curl -sS -X POST "$BASE2/v1/sessions" -H "$H1" -H "$H2" -H 'Content-Type: application/json' -d '{"mode":"cv"}' | python -m json.tool
echo 'Use the session ID returned above with /v1/sessions/{id}/image and /message; or the browser chatbot.'
