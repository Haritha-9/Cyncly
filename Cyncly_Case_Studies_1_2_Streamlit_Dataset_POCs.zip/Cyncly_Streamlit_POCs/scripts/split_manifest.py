"""Leakage-aware grouped train/validation/test split.
Usage: python scripts/split_manifest.py --input data/annotations.csv --output data/splits.csv
"""
import argparse
import csv
import hashlib
from pathlib import Path
import random
from collections import Counter, defaultdict


def split_rows(rows, seed=42):
    """Connect projects that share an identical image SHA before assigning splits.

    No (tenant,project) or duplicate-image SHA can cross split boundaries.
    Grouped splitting reduces leakage, but a production split still needs reviews
    for near-duplicates, shared sites, photographer, and capture sessions.
    """
    if not rows:
        return []
    parent = {}
    def root(x):
        parent.setdefault(x, x)
        if parent[x] != x:
            parent[x] = root(parent[x])
        return parent[x]
    def union(a,b):
        ra,rb = root(a),root(b)
        if ra != rb:
            parent[rb] = ra
    for row in rows:
        project = f"project:{row['tenant_id']}:{row['project_id']}"
        image = "sha:"+row["sha256"]
        union(project,image)
    groups = defaultdict(list)
    for row in rows:
        groups[root(f"project:{row['tenant_id']}:{row['project_id']}")].append(dict(row))
    ids = sorted(groups)
    random.Random(seed).shuffle(ids)
    n = len(ids)
    # Integer slicing; for very small manifests split sizes may be unrepresentative.
    if n >= 3:
        # Reserve at least one independent group for validation and test.
        train_end = min(max(1, round(0.7*n)), n-2)
        val_end = min(max(train_end+1, round(0.85*n)), n-1)
    else:
        train_end = 1
        val_end = n  # tiny toy sets cannot support a proper three-way split
    output=[]
    for i,gid in enumerate(ids):
        label = "train" if i < train_end else "val" if i < val_end else "test"
        for row in groups[gid]:
            row["split"] = label
            output.append(row)
    return output


def validate(rows):
    errors=[]
    for i,row in enumerate(rows, 2):
        for field in ["tenant_id","project_id","image_path","sha256","label","x1","y1","x2","y2","reviewed"]:
            if field not in row:
                errors.append(f"line {i}: missing {field}")
        try:
            coords = [float(row[k]) for k in ("x1","y1","x2","y2")]
            if not (0<=coords[0]<coords[2] and 0<=coords[1]<coords[3]):
                errors.append(f"line {i}: invalid bounding box")
        except (KeyError, ValueError):
            errors.append(f"line {i}: missing/non-numeric box")
        if row.get("reviewed") != "yes":
            errors.append(f"line {i}: missing QA review")
    return errors


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--input",default="data/annotations.csv")
    parser.add_argument("--output",default="data/splits.csv")
    parser.add_argument("--seed",type=int,default=42)
    args=parser.parse_args()
    with open(args.input,newline="",encoding="utf-8") as f:
        rows=list(csv.DictReader(f))
    errors=validate(rows)
    if errors:
        raise SystemExit("Annotation QA failed:\n"+"\n".join(errors))
    result=split_rows(rows,args.seed)
    with open(args.output,"w",newline="",encoding="utf-8") as f:
        writer=csv.DictWriter(f,fieldnames=list(result[0]))
        writer.writeheader();writer.writerows(result)
    for split in ("train","val","test"):
        items=[r for r in result if r["split"]==split]
        print(split,"images/annotations:",len(items),"classes:",dict(Counter(r["label"] for r in items)))
    # defensive assertions
    for field in ("sha256",):
        groups=defaultdict(set)
        for row in result: groups[row[field]].add(row["split"])
        assert all(len(values)==1 for values in groups.values())
    print("Saved",args.output,"; group/duplicate leakage checks passed")

if __name__=="__main__": main()
