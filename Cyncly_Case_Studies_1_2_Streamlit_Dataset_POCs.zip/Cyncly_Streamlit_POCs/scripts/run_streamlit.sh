#!/usr/bin/env bash
# Run two FastAPI services and two independent Streamlit apps locally.
set -euo pipefail
cd "$(dirname "$0")/.."
if [ ! -d .venv ]; then
  if command -v python3 >/dev/null; then python3 -m venv .venv; else python -m venv .venv; fi
fi
. .venv/bin/activate
python -m pip install -r requirements-ui.txt
python scripts/generate_samples.py
python scripts/import_demo_dataset.py
export CASE1_URL="http://127.0.0.1:8001"
export CASE2_URL="http://127.0.0.1:8002"
export STREAMLIT_BROWSER_GATHER_USAGE_STATS=false
python -m uvicorn case1.main:app --host 127.0.0.1 --port 8001 & P1=$!
python -m uvicorn case2.main:app --host 127.0.0.1 --port 8002 & P2=$!
python -m streamlit run ui/case1_streamlit.py --server.headless true --server.address 127.0.0.1 --server.port 8501 & P3=$!
python -m streamlit run ui/case2_streamlit.py --server.headless true --server.address 127.0.0.1 --server.port 8502 & P4=$!
cleanup() { kill "$P1" "$P2" "$P3" "$P4" 2>/dev/null || true; wait 2>/dev/null || true; }
trap cleanup EXIT INT TERM
printf '\nCASE 1 STREAMLIT: http://127.0.0.1:8501\nCASE 2 STREAMLIT: http://127.0.0.1:8502\nAPI docs: http://127.0.0.1:8001/docs and http://127.0.0.1:8002/docs\nPress Ctrl+C to stop.\n\n'
wait -n "$P1" "$P2" "$P3" "$P4"
