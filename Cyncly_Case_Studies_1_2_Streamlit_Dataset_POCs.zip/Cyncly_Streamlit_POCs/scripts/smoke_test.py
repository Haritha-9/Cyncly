"""Live end-to-end smoke check. First run both APIs.
    python scripts/smoke_test.py
"""
import json
from pathlib import Path
import httpx

ROOT=Path(__file__).resolve().parents[1]
C1="http://127.0.0.1:8001"
C2="http://127.0.0.1:8002"
H={"X-Tenant-ID":"alpha","X-API-Key":"alpha-demo-key"}


def require(response):
    if not response.is_success:
        raise RuntimeError(f"HTTP {response.status_code}: {response.text}")
    return response.json()


def main():
    with httpx.Client(timeout=120) as client:
        print("Health 1:",require(client.get(C1+"/health")))
        print("Health 2:",require(client.get(C2+"/health")))
        room=(ROOT/"data/samples/room.png").read_bytes()
        result=require(client.post(C1+"/v1/predict",headers=H,files={"file":("room.png",room,"image/png")}))
        print("Case 1 boxes:",[(d["label"],d["bbox"]) for d in result["detections"]])
        assert result["detections"],"No marker detections: check model registry"
        session=require(client.post(C2+"/v1/sessions",headers=H,json={"mode":"cv"}))
        sid=session["session_id"]
        uploaded=require(client.post(C2+f"/v1/sessions/{sid}/image",headers=H,files={"file":("room.png",room,"image/png")}))
        print("Case 2 chatbot:",uploaded["reply"][:180],"...")
        chosen=require(client.post(C2+f"/v1/sessions/{sid}/message",headers=H,json={"message":"choose 1"}))
        print("Human confirmation:",chosen["selected_sku"])
        require(client.post(C2+f"/v1/sessions/{sid}/feedback",headers=H,
                            json={"accepted":True,"assisted_minutes":1.5,"cost_usd":0.02,"error_type":"none"}))
        print("Tenant metrics:",require(client.get(C1+"/v1/analytics/tenant",headers=H)))
        print("Pilot decision:",require(client.get(C2+"/v1/pilot/decision",headers=H))["status"])
        print("SMOKE CHECK PASSED. Open http://127.0.0.1:8002/")

if __name__=="__main__":main()
