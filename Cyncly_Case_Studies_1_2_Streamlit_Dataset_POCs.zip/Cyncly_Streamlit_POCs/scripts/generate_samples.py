"""Creates synthetic color-marker image fixtures for the offline demonstration."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "data" / "samples"
OUT.mkdir(parents=True, exist_ok=True)
COLORS = {"chair":(54,105,205), "dining table":(235,158,43),
          "couch":(72,164,104),"bed":(168,85,177),"book":(211,74,108)}


def scene(name, placements):
    img = Image.new("RGB",(720,450),"white")
    d = ImageDraw.Draw(img)
    d.text((24,16),"SYNTHETIC MARKER DEMO: NOT REAL FURNITURE RECOGNITION",fill="black")
    for label,(x1,y1,x2,y2) in placements:
        d.rectangle([x1,y1,x2,y2],fill=COLORS[label])
        d.text((x1+8,y1+8),label,fill="white")
    img.save(OUT/f"{name}.png")

scene("room",[("chair",(65,115,220,350)),("dining table",(275,205,570,335)),("book",(540,92,640,166))])
scene("living_room",[("couch",(110,195,495,347)),("book",(560,220,645,322))])
scene("bedroom",[("bed",(90,145,520,350)),("chair",(565,190,660,335))])
print(f"Generated 3 synthetic demo images in {OUT}")
