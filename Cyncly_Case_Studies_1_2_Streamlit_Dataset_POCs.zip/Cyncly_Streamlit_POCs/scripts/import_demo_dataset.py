"""Import already supplied, synthetic POC images into audited dataset format.

This step runs completely offline. It is NOT a real-world dataset.
"""
from pathlib import Path
import csv
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from dataset_tools.common import IMAGE_FIELDS, BOX_FIELDS, make_image_row, write_csv


def main():
    source = ROOT / "data/splits.csv"
    output = ROOT / "data/demo_import"
    with source.open(newline="", encoding="utf-8") as f:
        existing = list(csv.DictReader(f))
    image_rows, box_rows, seen = [], [], set()
    for row in existing:
        path = ROOT / row["image_path"]
        image_id = path.stem
        if image_id not in seen:
            image_rows.append(make_image_row(
                path, image_id, row["split"], row["tenant_id"],
                row["project_id"], "reviewed", "synthetic_marker_demo"
            ))
            seen.add(image_id)
        box_rows.append({
            "image_id": image_id, "label": row["label"],
            **{k: row[k] for k in ("x1", "y1", "x2", "y2")},
            "reviewed": "yes"
        })
    write_csv(output / "images_manifest.csv", image_rows, IMAGE_FIELDS)
    write_csv(output / "boxes.csv", box_rows, BOX_FIELDS)
    print(f"Imported {len(image_rows)} synthetic demo images; {len(box_rows)} box labels into {output}")
    print("WARNING: synthetic markers only — real detection evaluation not established")

if __name__ == "__main__":
    main()
