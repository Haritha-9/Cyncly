"""Demonstrate bbox-safe augmentations. Apply to TRAIN split only."""
from PIL import Image, ImageEnhance, ImageOps


def flip_with_boxes(image, objects):
    flipped=ImageOps.mirror(image)
    boxes=[]
    for obj in objects:
        x1,y1,x2,y2=obj["bbox"]
        boxes.append({**obj,"bbox":[image.width-x2,y1,image.width-x1,y2]})
    return flipped,boxes


def brightness(image,factor):
    return ImageEnhance.Brightness(image).enhance(factor)
