"""Same-image detector benchmark. Marker mode is synthetic only, NOT meaningful CV accuracy.
Example: python scripts/benchmark_models.py --models marker-v1 --images data/samples
Optional: --models yolo11n fasterrcnn --images /path/to/frozen/real_photo_test_set
"""
import argparse
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import json
from pathlib import Path
import statistics
import time
from PIL import Image,ImageOps
from case1.detection import DetectorFactory
from case1.registry import Registry


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--models', nargs='+',default=['marker-v1'])
    p.add_argument('--images',default='data/samples')
    p.add_argument('--output',default='data/model_benchmark.json')
    a=p.parse_args()
    images=sorted(x for x in Path(a.images).glob('*') if x.suffix.lower() in ('.jpg','.jpeg','.png','.webp'))
    if not images:raise SystemExit('No images found')
    reg=Registry(Path('data'))
    configured=reg.read()['models'];factory=DetectorFactory()
    report={}
    for name in a.models:
        if name not in configured:raise SystemExit(f'Unknown model: {name}')
        detector=factory.get(name,configured[name])
        records=[]
        for path in images:
            image=ImageOps.exif_transpose(Image.open(path)).convert('RGB')
            start=time.perf_counter()
            detections=detector.predict(image)
            milliseconds=round((time.perf_counter()-start)*1000,2)
            records.append({'image_id':path.stem,'detections':detections,'latency_ms':milliseconds})
        latencies=sorted(row['latency_ms'] for row in records)
        p95=latencies[max(0,int(len(latencies)*.95+.999)-1)]
        report[name]={'backend':configured[name]['backend'],
                      'avg_latency_ms':round(statistics.mean(latencies),2),
                      'p95_latency_ms':p95,
                      'predictions':records}
        print(f'{name}: avg={report[name]["avg_latency_ms"]} ms; p95={p95} ms; images={len(records)}')
    Path(a.output).write_text(json.dumps(report,indent=2),encoding='utf-8')
    print('Saved:',a.output)
    print('NOTE: speed figures depend on this machine; quality needs a frozen labeled REAL dataset.')

if __name__=='__main__':main()
