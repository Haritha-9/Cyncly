"""Optional: request a SMALL, annotated Open Images V7 subset via FiftyOne.

This deliberately does not run automatically; it installs a large dependency and
may download hundreds of MB of datasets/metadata. Each image has its own reuse rights.

  python -m pip install -r requirements-openimages.txt
  python scripts/download_openimages_v7.py --max-samples 12 --split validation

Output: data/openimages_export/{split}/images etc. Open Images annotations are
third-party ground truth, NOT a human review performed by the Cyncly POC team.
Do not add --reviewed on import until label QA is completed.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--split", choices=["train", "validation", "test"], default="validation")
    p.add_argument("--classes", nargs="+", default=["Chair", "Couch", "Bed"])
    p.add_argument("--max-samples", type=int, default=12)
    p.add_argument("--output", type=Path, default=ROOT / "data" / "openimages_export")
    a = p.parse_args()
    if not 1 <= a.max_samples <= 50:
        p.error("Restrict this demo to 1..50 samples per request")
    try:
        import fiftyone as fo
        import fiftyone.zoo as foz
    except ImportError as exc:
        raise SystemExit("FiftyOne missing. See requirements-openimages.txt") from exc
    fo_split = a.split
    export_split = "valid" if fo_split == "validation" else fo_split
    sample = foz.load_zoo_dataset(
        "open-images-v7", split=fo_split, label_types=["detections"],
        classes=a.classes, max_samples=a.max_samples, shuffle=True, seed=42,
        dataset_name=f"cyncly_poc_openimages_{fo_split}_{a.max_samples}",
    )
    destination = a.output / export_split
    sample.export(export_dir=str(destination), dataset_type=fo.types.YOLOv5Dataset,
                  label_field="ground_truth", classes=a.classes)
    print(json.dumps({"count":len(sample), "export":str(destination),
                      "warning":"Third-party labels are not independently QA reviewed. Check licenses and annotation coverage before evaluating."},indent=2))


if __name__ == "__main__":
    main()
