#!/usr/bin/env bash
# Launch both FastAPI apps with Ctrl+C cleanup (macOS/Linux).
set -euo pipefail
cd "$(dirname "$0")/.."
PY=python3
if ! command -v "$PY" >/dev/null; then PY=python; fi
if [ ! -d .venv ]; then "$PY" -m venv .venv; fi
. .venv/bin/activate
python -m pip install -r requirements.txt
python scripts/generate_samples.py
python -m pytest -q
export CASE1_URL=http://127.0.0.1:8001
uvicorn case1.main:app --port 8001 --host 127.0.0.1 &
P1=$!
uvicorn case2.main:app --port 8002 --host 127.0.0.1 &
P2=$!
trap 'kill "$P1" "$P2" 2>/dev/null || true' EXIT INT TERM
echo 'Case 1 API: http://127.0.0.1:8001/docs'
echo 'Case 2 chatbot: http://127.0.0.1:8002/'
echo 'Case 2 API: http://127.0.0.1:8002/docs'
echo 'Run python scripts/smoke_test.py in a second terminal. Ctrl+C to stop.'
wait
