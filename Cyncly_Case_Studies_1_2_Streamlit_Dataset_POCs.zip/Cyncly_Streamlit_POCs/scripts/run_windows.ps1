# Windows PowerShell: run from any directory, press Ctrl+C to stop servers.
$ErrorActionPreference = 'Stop'
Set-Location (Join-Path $PSScriptRoot '..')
if (-not (Test-Path .venv)) { py -3 -m venv .venv }
$python = (Resolve-Path '.venv\Scripts\python.exe').Path
& $python -m pip install -r requirements.txt
if ($LASTEXITCODE -ne 0) { throw 'pip install failed' }
& $python scripts/generate_samples.py
& $python -m pytest -q
if ($LASTEXITCODE -ne 0) { throw 'Automated tests failed' }
$env:CASE1_URL = 'http://127.0.0.1:8001'
$p1 = Start-Process -FilePath $python -ArgumentList '-m','uvicorn','case1.main:app','--host','127.0.0.1','--port','8001' -PassThru
$p2 = Start-Process -FilePath $python -ArgumentList '-m','uvicorn','case2.main:app','--host','127.0.0.1','--port','8002' -PassThru
try {
    Write-Host 'Case 1: http://127.0.0.1:8001/docs'
    Write-Host 'Case 2 chatbot: http://127.0.0.1:8002/'
    Write-Host 'In another window run: .venv\Scripts\python.exe scripts\smoke_test.py'
    Write-Host 'Press Ctrl+C to stop the launcher; processes may also be closed from Task Manager.'
    while ($true) { Start-Sleep -Seconds 2 }
}
finally {
    if ($p1 -and -not $p1.HasExited) { Stop-Process -Id $p1.Id -Force }
    if ($p2 -and -not $p2.HasExited) { Stop-Process -Id $p2.Id -Force }
}
