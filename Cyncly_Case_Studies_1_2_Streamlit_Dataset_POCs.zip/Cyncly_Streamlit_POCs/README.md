# Cyncly Senior AI Engineer — Case Studies 1 & 2 runnable proof of concept

**Two connected FastAPI services, a browser chatbot, test suite, sample data, and exact commands.**

This is an illustrative technical implementation based on the user-provided Senior AI Engineer case-study brief and the previously discussed high-level/low-level architectures. It is **not** Cyncly software, customer data, production-ready security, or an independently validated computer-vision model.

## Quick start

**macOS/Linux:** `bash scripts/run_local.sh`  
**Windows:** `powershell -ExecutionPolicy Bypass -File .\scripts\run_windows.ps1`  
**Docker:** `docker compose up --build`

Open the **Case Study 2 chatbot** at **http://127.0.0.1:8002/**, select the CV scenario, start a session, and choose a sample image. Case 1 runs at **http://127.0.0.1:8001/docs**. Full commands: [RUN_COMMANDS.md](RUN_COMMANDS.md).

## What you can demonstrate live

| Case | Demo operation | Code paths |
|---|---|---|
| 1 | Authenticated image upload → validation → preprocessing → detector → JSON boxes | `case1/main.py`, `case1/images.py`, `case1/detection.py` |
| 1 | Per-tenant metadata and predictions | `case1/auth.py`, `case1/storage.py` |
| 1 | Human feedback and customer-specific missed-detection proxy | `POST /v1/predictions/{id}/feedback`, `GET /v1/analytics/tenant` |
| 1 | Basic image-quality drift monitoring and Prometheus metrics | `GET /v1/analytics/drift`, `GET /metrics` |
| 1 | Model version selection, canary rollout, controlled rollback | `case1/registry.py`, `/v1/admin/models/*` |
| 1 | Optional asynchronous in-process jobs | `POST /v1/jobs`, `GET /v1/jobs/{id}` |
| 1 | Leakage-aware dataset split, annotation QA, bbox-safe augmentation | `scripts/split_manifest.py`, `scripts/augment_demo.py` |
| 1 | IoU=0.5 precision/recall evaluation and model latency benchmark | `scripts/score_detections.py`, `scripts/benchmark_models.py` |
| 2 | Compare manual/rules, CV + chatbot, and advanced-assisted variants | `case2/main.py`, `GET /v1/pilot/options` |
| 2 | Interactive image-upload chat, correction, confidence explanation, human handoff | `case2/static/index.html`, `case2/chat.py` |
| 2 | Tenant-isolated sessions, catalogue category mapping and explicit confirmation | `case2/main.py`, `case2/catalog.py` |
| 2 | Record baseline/assisted time, costs, outcomes and errors; per-option pilot metrics | `/v1/sessions/{id}/feedback`, `/v1/pilot/metrics` |
| 2 | Discovery questions and illustrative go/no-go quality gates | `/v1/pilot/discovery`, `/v1/pilot/decision` |
| 2 | Optional real external image-description model (explicit opt-in) | `case2/main.py::optional_vlm_description` |

## How the services connect

```mermaid
flowchart LR
  User[Customer/project app or browser chatbot] --> C2[Case 2 API: sessions + guided chat]
  C2 --> Choice{Pilot option}
  Choice --> Manual[Manual keyword and human confirmation]
  Choice --> CV[CV-assisted: image upload]
  Choice --> Advanced[Advanced-assisted: CV + optional VLM description]
  CV --> C1[Case 1 REST detector API]
  Advanced --> C1
  C1 --> Pre[Image validation + EXIF normalize + quality features]
  Pre --> Model[Pluggable detector: synthetic marker / YOLO / Faster R-CNN]
  Model --> Predictions[Boxes + category labels + confidence]
  Predictions --> Metadata[(SQLite metadata + local image store)]
  Predictions --> C2
  C2 --> Catalog[Category-to-example-catalogue matching]
  Catalog --> Review[Chatbot suggestions -> customer confirmation / human review]
  Review --> Pilot[(Pilot outcome measurements)]
  Metadata --> Monitor[Per-tenant metrics + drift + feedback]
  Pilot --> Decide[Discovery / baseline / go-no-go decision]
```

## Example response

The included artificial `room.png` image has colored rectangles that are **markers for the simulated detector**. In default mode Case 1 returns:

```json
{
  "model_version": "marker-v1",
  "backend": "marker",
  "demo_only": true,
  "detections": [
    {"label": "chair", "confidence": 0.93, "bbox": [65, 115, 223, 353]},
    {"label": "dining table", "confidence": 0.93, "bbox": [275, 205, 573, 338]}
  ]
}
```

*The coordinates above are illustrative of marker regions; actual output includes more objects and measured coordinates.*

The Case 2 catalogue maps **category** `chair` to mock SKU `DEMO-CHAIR-01`, but never claims this is an exact visual product identification. It only finalizes after a user sends `choose 1`. Otherwise the user may correct the class, ask why a recommendation was made, or request `human` review.

## Three solution options in Case Study 2

1. **Manual/rules baseline**: lightweight catalogue search, no AI, human chooses product. Start here to measure the current task time and mistakes.
2. **Conventional CV + assisted chatbot (recommended pilot)**: Case 1 model predicts broad object categories and the chatbot asks for confirmation. Good for a bounded, auditable trial.
3. **Advanced AI**: same grounded catalogue and confirmation path, with optional VLM image description if `VLM_ENABLED=1`, `OPENAI_API_KEY` is present and optional packages are installed. When off, *advanced mode demonstrates the UX only; it does not call a true multimodal LLM.*

## Real AI model activation (optional)

The default **marker detector is deliberately synthetic**, works offline, and is not an acceptable substitute for a real CV accuracy measurement. To detect broad real-photo objects:

```bash
python -m pip install -r requirements-ai.txt
```

Then activate YOLO with the admin endpoint (see [RUN_COMMANDS.md](RUN_COMMANDS.md)); the first prediction may download the pretrained `yolo11n.pt` weights. To compare with Faster R-CNN, install a compatible `torch` / `torchvision` and activate the `fasterrcnn` model entry. Evaluate on a **real, leakage-free, representative, labeled test set** with COCO mAP; this PoC includes only a simple IoU=0.5 precision/recall scorer, not full mAP.

## Key source files

- `case1/main.py`: detector REST endpoints, quality signals, auth, metadata, queue-like background job, canary controls.
- `case1/detection.py`: shared detector contract + marker, real YOLO and optional Faster R-CNN adapters.
- `case1/registry.py`: local model registry and rollback history.
- `case2/main.py`: chatbot sessions, image routing to Case 1, observation metrics and pilot decisions.
- `case2/chat.py`: deterministic guided assistant that cannot independently commit an exact SKU.
- `case2/static/index.html`: self-contained interactive chatbot browser UI.
- `scripts/`: fixtures, data splits, model evaluation, benchmarks and end-to-end smoke test.
- `tests/`: API, tenant isolation, release, chat, metrics, data integrity and evaluation tests.
- `docs/`: architecture breakdown, requirement mapping, interview Q&As and production-gap checklist.

## Important production gaps

SQLite, local files, a file-based registry and FastAPI BackgroundTasks intentionally stand in for PostgreSQL, S3, MLflow and durable queues. There is no real OAuth2/OIDC, Kubernetes cluster, annotation workflow, reviewed domain dataset, per-user RBAC, production tracing, certified mAP evaluation, consent workflow, automated retraining, or security hardening. Demo keys must not be reused in production. The optional VLM sends images to an external provider and should only be used with explicit organizational approval and appropriate data-handling controls. See [docs/PRODUCTION_GAPS.md](docs/PRODUCTION_GAPS.md).

## Interview speaking points

**Case 1**: "I separated the API, image validation, detector backend, persistent prediction metadata, monitoring, and model lifecycle so each service has one responsibility. I can compare detector families on the same frozen dataset, release gradually, and roll back if customer-level false negatives rise."

**Case 2**: "Before scaling AI, I establish a manual baseline and measure time saved, correction burden, false matches, customer acceptance and operating cost. The chatbot makes suggestions explainable and keeps people in control; I only recommend scaling when pre-agreed pilot gates have credible evidence."

See [docs/INTERVIEW_QA.md](docs/INTERVIEW_QA.md) for likely interview questions and answers.

---

## NEW: Streamlit UIs + labeled dataset import, validation and web test images

There are now **two separate Streamlit interfaces** in addition to the original FastAPI services:

- **Case Study 1 — http://127.0.0.1:8501**: image upload and box overlay, annotated YOLO ZIP import, dataset validation, optional Wikimedia Commons web-image collection, monitoring, release controls.
- **Case Study 2 — http://127.0.0.1:8502**: guided image+chatbot pilot, catalogue suggestions, user confirmation, comparison of three approaches, observations and go/no-go metrics.

**Run both UIs and both API services** from the project root:

```bash
bash scripts/run_streamlit.sh  # macOS / Linux
# or
powershell -ExecutionPolicy Bypass -File .\scripts\run_streamlit_windows.ps1  # Windows
# or
# docker compose up --build
```

**Full instructions, CLI examples, validation caveats, sources and interview workflow:** [docs/STREAMLIT_AND_DATASETS.md](docs/STREAMLIT_AND_DATASETS.md).

Real web images **are never automatically treated as annotated test ground truth**. Labeled YOLO datasets need verified, leakage-free boxes and customer-specific evaluation. The original Python/FastAPI endpoints and marker-mode demos remain available.
