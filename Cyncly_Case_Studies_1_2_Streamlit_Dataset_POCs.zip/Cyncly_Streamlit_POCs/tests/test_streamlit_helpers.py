"""Backend-independent checks for Streamlit data safety and image overlay."""
from io import BytesIO
import zipfile
from pathlib import Path
from unittest.mock import Mock, patch
import pytest
from PIL import Image

from ui.datasets import safe_extract_yolo_zip, validate_manifests
from ui.common import APIError, preview_with_boxes, request_json


def archive_with(items: dict[str, bytes]) -> bytes:
    buffer = BytesIO()
    with zipfile.ZipFile(buffer, "w") as z:
        for filename, content in items.items():
            z.writestr(filename, content)
    return buffer.getvalue()


def test_safe_yolo_zip_extracts_expected_files(tmp_path):
    data = archive_with({"dataset/data.yaml": b"names: [chair]",
                         "dataset/train/labels/sample.txt": b"0 0.5 0.5 0.5 0.5"})
    root = safe_extract_yolo_zip(data, tmp_path)
    assert root == tmp_path / "dataset"
    assert (root / "train/labels/sample.txt").exists()


@pytest.mark.parametrize("filename", ["../outside/data.yaml", "/tmp/data.yaml", "test.exe"])
def test_safe_yolo_zip_blocks_traversal_or_unexpected_files(tmp_path, filename):
    data = archive_with({filename: b"bad", "dataset/data.yaml": b"names: [chair]"})
    with pytest.raises(ValueError):
        safe_extract_yolo_zip(data, tmp_path)


def test_safe_yolo_zip_rejects_many_files(tmp_path):
    data = archive_with({f"train/images/{i}.txt": b"x" for i in range(3)} | {"data.yaml": b"names: [a]"})
    with pytest.raises(ValueError, match="too many"):
        safe_extract_yolo_zip(data, tmp_path, max_members=2)


def test_overlay_marks_box():
    img = Image.new("RGB", (120, 120), "white")
    b = BytesIO()
    img.save(b, format="PNG")
    overlay = preview_with_boxes(b.getvalue(), [{"label": "chair", "bbox": [10, 20, 60, 70], "confidence": 0.95}])
    assert overlay.size == (120, 120)
    assert overlay.getpixel((10, 30)) != (255, 255, 255)


def test_overlay_skips_low_confidence():
    img = Image.new("RGB", (120, 120), "white")
    b = BytesIO(); img.save(b, format="PNG")
    result = preview_with_boxes(b.getvalue(), [{"label":"table", "bbox":[1,1,40,40],"confidence":0.2}], 0.5)
    assert result.getpixel((1,1)) == (255,255,255)


def test_api_client_sets_tenant_headers():
    r = Mock()
    r.json.return_value = {"status":"ok"}
    with patch("requests.request", return_value=r) as request:
        assert request_json("http://127.0.0.1:8001", "GET", "/health", tenant="alpha", api_key="abc") == {"status":"ok"}
        assert request.call_args.kwargs["headers"] == {"X-Tenant-ID":"alpha","X-API-Key":"abc"}


def test_api_client_displays_connection_error():
    import requests
    with patch("requests.request", side_effect=requests.ConnectionError()):
        with pytest.raises(APIError, match="Start its FastAPI"):
            request_json("http://127.0.0.1:8001", "GET", "/health")
