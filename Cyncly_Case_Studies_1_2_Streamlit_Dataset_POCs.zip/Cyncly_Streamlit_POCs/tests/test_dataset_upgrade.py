"""Dataset handling: real label ingestion and scraped-content metadata checks."""
from io import BytesIO
from pathlib import Path
import json
import zipfile
from PIL import Image
from ui.datasets import import_uploaded_yolo_zip
from scripts.scrape_test_images import metadata_from_page, parse_gallery_files


def make_zip() -> bytes:
    im = Image.new("RGB", (96, 96), "white")
    raw = BytesIO(); im.save(raw, format="PNG")
    out = BytesIO()
    with zipfile.ZipFile(out, "w") as z:
        z.writestr("demo/data.yaml", "names: [chair]")
        for split in ("train", "valid", "test"):
            z.writestr(f"demo/{split}/images/scene.png", raw.getvalue())
            z.writestr(f"demo/{split}/labels/scene.txt", "0 0.5 0.5 0.5 0.5\n")
    return out.getvalue()


def test_import_yolo_zip_creates_manifest_and_qa_report(tmp_path):
    result = import_uploaded_yolo_zip(make_zip(), tenant="alpha", reviewed=True, out_root=tmp_path)
    assert result["images"] == 3
    assert result["boxes"] == 3
    assert result["validation"]["counts"]["boxes"] == 3
    # Identical images in train/valid/test are correctly flagged as leakage!
    assert result["validation"]["status"] == "FAIL"
    assert any("Exact image data leakage" in e for e in result["validation"]["errors"])


def test_unreviewed_yolo_labels_not_scored(tmp_path):
    result = import_uploaded_yolo_zip(make_zip(), tenant="alpha", reviewed=False, out_root=tmp_path)
    assert result["boxes"] == 0
    assert result["human_review_confirmed"] is False


def test_scraper_gallery_parser():
    html = '<div class="gallerytext"><a href="/wiki/File:Wooden_chair.jpg">Chair</a></div>'
    assert parse_gallery_files(html) == ["File:Wooden chair.jpg"]


def test_scraper_skips_unknown_license():
    meta = {"title":"File:Chair.jpg", "imageinfo":[{"mime":"image/jpeg",
            "thumburl":"https://upload.wikimedia.org/image.jpg",
            "extmetadata":{"LicenseShortName":{"value":"All rights reserved"}}}]}
    assert metadata_from_page(meta) is None


def test_scraper_accepts_cc_by_attributed_files():
    meta = {"title":"File:Chair.jpg", "imageinfo":[{"mime":"image/jpeg",
            "thumburl":"https://upload.wikimedia.org/image.jpg",
            "extmetadata":{"LicenseShortName":{"value":"CC BY-SA 4.0"},
                           "LicenseUrl":{"value":"https://creativecommons.org/licenses/by-sa/4.0/"},
                           "Artist":{"value":"Example Photographer"}}}]}
    item = metadata_from_page(meta)
    assert item is not None
    assert item["author"] == "Example Photographer"
    assert item["license"] == "CC BY-SA 4.0"
