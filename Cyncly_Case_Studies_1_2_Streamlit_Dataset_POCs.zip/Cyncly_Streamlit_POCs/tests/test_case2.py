from .conftest import CREDENTIALS as H, BETA


def create(client,mode='cv',headers=H):
    result=client.post('/v1/sessions',headers=headers,json={'mode':mode})
    assert result.status_code==201,result.text
    return result.json()['session_id']


def test_cv_image_chat_and_confirmation(client2,image_bytes):
    sid=create(client2)
    out=client2.post(f'/v1/sessions/{sid}/image',headers=H,
                     files={'file':('sample.png',image_bytes,'image/png')})
    assert out.status_code==200,out.text
    assert out.json()['suggestions'][0]['sku']=='DEMO-CHAIR-01'
    assert out.json()['demo_only'] is True
    selected=client2.post(f'/v1/sessions/{sid}/message',headers=H,json={'message':'choose 1'})
    assert selected.json()['selected_sku']=='DEMO-CHAIR-01'
    session=client2.get(f'/v1/sessions/{sid}',headers=H).json()
    assert session['state']=='confirmed' and len(session['messages'])>=4


def test_manual_baseline_does_not_infer(client2,image_bytes):
    sid=create(client2,'manual')
    r=client2.post(f'/v1/sessions/{sid}/image',headers=H,
                   files={'file':('sample.png',image_bytes,'image/png')})
    assert r.status_code==200 and r.json()['suggestions']==[]
    m=client2.post(f'/v1/sessions/{sid}/message',headers=H,json={'message':'correct chair'})
    assert len(m.json()['suggestions'])==1
    chosen=client2.post(f'/v1/sessions/{sid}/message',headers=H,json={'message':'choose 1'})
    assert chosen.json()['selected_sku']=='DEMO-CHAIR-01'


def test_human_review_escalation(client2):
    sid=create(client2)
    out=client2.post(f'/v1/sessions/{sid}/message',headers=H,json={'message':'human'})
    assert out.json()['state']=='human_review'
    assert out.json()['selected_sku'] is None


def test_tenant_session_isolation(client2):
    sid=create(client2)
    assert client2.get(f'/v1/sessions/{sid}',headers=BETA).status_code==404
    assert client2.post(f'/v1/sessions/{sid}/message',headers=BETA,json={'message':'hi'}).status_code==404


def test_record_pilot_metrics_and_gate(client2):
    sid=create(client2)
    response=client2.post(f'/v1/sessions/{sid}/feedback',headers=H,
        json={'accepted':True,'assisted_minutes':2.5,'cost_usd':0.03,'error_type':'none'})
    assert response.status_code==200
    assert client2.post(f'/v1/sessions/{sid}/feedback',headers=H,json={'accepted':True}).status_code==409
    metrics=client2.get('/v1/pilot/metrics',headers=H).json()
    assert metrics['by_mode']['cv']['observations']==1
    assert metrics['by_mode']['cv']['average_assisted_minutes']==2.5
    assert client2.get('/v1/pilot/decision',headers=H).json()['status']=='insufficient_evidence'


def test_three_options_discovery_and_catalog(client2):
    assert len(client2.get('/v1/pilot/options').json()['options'])==3
    assert len(client2.get('/v1/pilot/discovery').json()['product'])>=2
    assert len(client2.get('/v1/catalog',headers=H).json()['items'])==5
    assert client2.get('/').status_code==200


def test_advanced_is_explicitly_optional(client2,image_bytes):
    sid=create(client2, 'advanced')
    reply=client2.post(f'/v1/sessions/{sid}/image',headers=H,
        files={'file':('sample.png',image_bytes,'image/png')}).json()
    assert reply['vlm_used'] is False
    assert reply['suggestions']
