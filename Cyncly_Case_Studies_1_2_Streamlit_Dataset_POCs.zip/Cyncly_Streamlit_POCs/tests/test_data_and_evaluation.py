from PIL import Image
from scripts.augment_demo import flip_with_boxes
from scripts.split_manifest import split_rows,validate
from scripts.score_detections import score,iou


def test_split_prevents_cross_project_duplicate_leakage():
    base=[{'tenant_id': 'alpha','project_id': 'a','sha256':'same','label':'chair'},
          {'tenant_id': 'alpha','project_id': 'b','sha256':'same','label':'chair'},
          {'tenant_id': 'beta','project_id': 'c','sha256':'new','label':'bed'},
          {'tenant_id': 'beta','project_id': 'd','sha256':'unique','label':'couch'}]
    outputs=split_rows(base,seed=42)
    assert len({r['split'] for r in outputs if r['sha256']=='same'})==1


def test_annotation_rejects_missing_review_and_invalid_bbox():
    row={'tenant_id':'a','project_id':'p','image_path':'im.png','sha256':'123',
         'label':'chair','x1':'50','y1':'20','x2':'10','y2':'30','reviewed':'no'}
    assert len(validate([row]))==2


def test_iou_and_detection_scoring():
    assert iou([0,0,10,10],[0,0,10,10])==1
    truth=[{'image_id':'1','detections':[{'label':'chair','bbox':[0,0,10,10]}]}]
    pred=[{'image_id':'1','detections':[{'label':'chair','bbox':[0,0,10,10],'confidence':.9}]}]
    result=score(truth,pred)
    assert result['chair']['precision']==1 and result['chair']['recall']==1


def test_augmentation_updates_boxes():
    image=Image.new('RGB',(100,100),'white')
    flipped,boxes=flip_with_boxes(image,[{'label':'chair','bbox':[10,20,30,40]}])
    assert flipped.size==(100,100)
    assert boxes[0]['bbox']==[70,20,90,40]
