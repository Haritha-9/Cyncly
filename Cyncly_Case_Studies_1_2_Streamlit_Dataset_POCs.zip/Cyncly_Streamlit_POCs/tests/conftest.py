from io import BytesIO
from pathlib import Path
import pytest
from PIL import Image,ImageDraw
from fastapi.testclient import TestClient
from case1.config import Settings as Case1Settings
from case1.main import create_app as case1_app
from case2.config import Settings as Case2Settings
from case2.main import create_app as case2_app

CREDENTIALS={"X-Tenant-ID":"alpha","X-API-Key":"alpha-demo-key"}
BETA={"X-Tenant-ID":"beta","X-API-Key":"beta-demo-key"}


@pytest.fixture
def image_bytes():
    image=Image.new("RGB",(300,200),"white")
    ImageDraw.Draw(image).rectangle((55,40,200,155), fill=(54,105,205))
    out=BytesIO();image.save(out,format="PNG")
    return out.getvalue()


@pytest.fixture
def client1(tmp_path):
    app=case1_app(Case1Settings(data_dir=tmp_path,tenant_keys={"alpha":"alpha-demo-key","beta":"beta-demo-key"},admin_key="admin-test"))
    with TestClient(app) as client:yield client


class FakeGateway:
    async def predict(self,image_bytes,filename,tenant,key):
        return {"prediction_id":"fake-123","backend":"marker","demo_only":True,
                "detections":[{"label":"chair","confidence":0.94,"bbox":[10,10,80,80]}]}


@pytest.fixture
def client2(tmp_path):
    settings=Case2Settings(data_dir=tmp_path,case1_url="http://not-needed",
                           tenant_keys={"alpha":"alpha-demo-key","beta":"beta-demo-key"},
                           vlm_enabled=False,openai_model="gpt-4.1-mini")
    with TestClient(case2_app(settings,gateway=FakeGateway())) as client:yield client
