import io
from .conftest import CREDENTIALS as H, BETA


def predict(client,payload,headers=H):
    return client.post('/v1/predict',headers=headers,files={'file':('sample.png',payload,'image/png')})


def test_health(client1):
    assert client1.get('/health').json()['status']=='ok'


def test_marker_inference_and_metadata(client1,image_bytes):
    r=predict(client1,image_bytes)
    assert r.status_code==200,r.text
    data=r.json()
    assert data['backend']=='marker' and data['demo_only'] is True
    assert [d['label'] for d in data['detections']]==['chair']
    fetched=client1.get(f"/v1/predictions/{data['prediction_id']}",headers=H)
    assert fetched.status_code==200
    assert fetched.json()['model_version']=='marker-v1'


def test_invalid_image_rejected(client1):
    assert predict(client1,b'not an image').status_code==422
    assert predict(client1,b'').status_code==422


def test_tenant_access_isolation(client1,image_bytes):
    result=predict(client1,image_bytes).json()
    pid=result['prediction_id']
    assert client1.get(f'/v1/predictions/{pid}',headers=BETA).status_code==404
    assert client1.post(f'/v1/predictions/{pid}/feedback',headers=BETA,json={'accepted':False}).status_code==404
    assert predict(client1,image_bytes,headers={'X-Tenant-ID':'alpha','X-API-Key':'wrong'}).status_code==401


def test_feedback_analytics(client1,image_bytes):
    pid=predict(client1,image_bytes).json()['prediction_id']
    result=client1.post(f'/v1/predictions/{pid}/feedback',headers=H,json={'accepted':False,'missed_labels':['book']})
    assert result.status_code==200
    summary=client1.get('/v1/analytics/tenant',headers=H).json()
    assert summary['prediction_count']==1
    assert summary['user_reported_miss_rate']==1.0
    assert summary['p95_latency_ms']>=0


def test_rollout_canary_rollback(client1,image_bytes):
    admin={'X-Admin-Key':'admin-test'}
    state=client1.post('/v1/admin/models/rollout',headers=admin,
                       json={'active':'marker-v1','canary':'marker-v2','canary_percent':100})
    assert state.status_code==200
    assert predict(client1,image_bytes).json()['model_version']=='marker-v2'
    back=client1.post('/v1/admin/models/rollback',headers=admin)
    assert back.status_code==200
    assert predict(client1,image_bytes).json()['model_version']=='marker-v1'
    assert client1.get('/v1/admin/models').status_code==403


def test_async_jobs(client1,image_bytes):
    out=client1.post('/v1/jobs',headers=H,files={'file':('demo.png',image_bytes,'image/png')})
    assert out.status_code==202,out.text
    result=client1.get('/v1/jobs/'+out.json()['job_id'],headers=H)
    assert result.status_code==200
    assert result.json()['status']=='complete'


def test_drift_insufficient_samples(client1):
    assert client1.get('/v1/analytics/drift',headers=H).json()['status']=='insufficient_samples'


def test_metrics(client1):
    assert client1.get('/metrics').status_code==200
