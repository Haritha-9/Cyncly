"""Streamlit UIs for the two independent case-study APIs."""
