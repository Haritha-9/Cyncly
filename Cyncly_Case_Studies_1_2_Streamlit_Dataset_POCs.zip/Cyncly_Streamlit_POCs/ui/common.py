"""Small, testable HTTP client and presentation helpers for the Streamlit demos."""
from __future__ import annotations
from io import BytesIO
import os

import requests
from PIL import Image, ImageDraw, ImageOps


class APIError(RuntimeError):
    pass


def tenant_credentials() -> tuple[str, str]:
    """Default credentials are only for an explicitly local, non-production POC."""
    tenant = os.getenv("UI_TENANT", "alpha")
    default_keys = dict(p.split(":", 1) for p in os.getenv(
        "TENANT_KEYS", "alpha:alpha-demo-key,beta:beta-demo-key"
    ).split(",") if ":" in p)
    key = os.getenv("UI_API_KEY", default_keys.get(tenant, ""))
    return tenant, key


def request_json(base: str, method: str, endpoint: str, *, tenant: str | None = None,
                 api_key: str | None = None, admin_key: str | None = None,
                 json_data: dict | None = None, image: bytes | None = None,
                 filename: str = "image.png", timeout: int = 35) -> dict:
    """Centralize timeouts, POC tenant headers, and user-safe errors."""
    headers = {}
    if tenant is not None:
        headers["X-Tenant-ID"] = tenant
    if api_key is not None:
        headers["X-API-Key"] = api_key
    if admin_key is not None:
        headers["X-Admin-Key"] = admin_key
    kwargs = {"headers": headers, "timeout": timeout}
    if image is not None:
        mime = "image/jpeg" if filename.lower().endswith((".jpg", ".jpeg")) else "image/webp" if filename.lower().endswith(".webp") else "image/png"
        kwargs["files"] = {"file": (filename, image, mime)}
    elif json_data is not None:
        kwargs["json"] = json_data
    try:
        response = requests.request(method, base.rstrip("/") + endpoint, **kwargs)
        response.raise_for_status()
        return response.json()
    except requests.HTTPError as exc:
        detail = None
        try:
            detail = response.json().get("detail")
        except (ValueError, AttributeError):
            pass
        raise APIError(f"API returned HTTP {response.status_code}: {str(detail or response.text)[:220]}") from exc
    except (requests.ConnectionError, requests.Timeout) as exc:
        raise APIError(f"Cannot reach {base}. Start its FastAPI service first.") from exc
    except ValueError as exc:
        raise APIError("API did not return valid JSON") from exc


def preview_with_boxes(raw: bytes, detections: list[dict], confidence_floor: float = 0) -> Image.Image:
    """Read uploaded image only into memory; display predicted bounding boxes."""
    with Image.open(BytesIO(raw)) as im:
        image = ImageOps.exif_transpose(im).convert("RGB")
    draw = ImageDraw.Draw(image)
    for item in detections:
        conf = float(item.get("confidence", 0))
        if conf < confidence_floor:
            continue
        x1, y1, x2, y2 = [float(v) for v in item.get("bbox", [0, 0, 0, 0])]
        x1, y1, x2, y2 = (max(0, x1), max(0, y1), min(image.width, x2), min(image.height, y2))
        if x2 <= x1 or y2 <= y1:
            continue
        draw.rectangle((x1, y1, x2, y2), outline="#10b981", width=max(2, image.width // 350))
        text = f"{item.get('label', 'object')} {conf:.0%}"
        draw.rectangle((x1, max(0, y1-20), min(image.width, x1+len(text)*8+6), y1), fill="#064e3b")
        draw.text((x1+3, max(0, y1-18)), text, fill="white")
    return image
