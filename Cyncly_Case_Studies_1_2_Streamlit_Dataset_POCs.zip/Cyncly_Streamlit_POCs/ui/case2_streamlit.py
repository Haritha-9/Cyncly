"""Case Study 2 Streamlit: business-first computer-vision chatbot + pilot dashboard.

Run with both existing APIs:
    streamlit run ui/case2_streamlit.py --server.port 8502
"""
from __future__ import annotations
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import streamlit as st
from ui.common import APIError, request_json, tenant_credentials

st.set_page_config(page_title="Case 2 · Product Assistant POC", page_icon="💬", layout="wide")
BASE = os.getenv("CASE2_URL", "http://127.0.0.1:8002")
tenant, key = tenant_credentials()
st.title("Case Study 2 · Product Identification Assistant")
st.caption("Business-first AI pilot · image + chatbot · human confirmation · pilot decisions")
st.info("This is a **guided demo chatbot**, not a free-form AI agent. Category suggestions come from Case 1; "
        "the catalogue is illustrative, and a customer must confirm a selection.")


def api(method: str, endpoint: str, **kwargs) -> dict:
    return request_json(BASE, method, endpoint, tenant=tenant, api_key=key, **kwargs)


def new_session(mode: str) -> None:
    result = api("POST", "/v1/sessions", json_data={"mode":mode})
    st.session_state["case2_session"] = result["session_id"]
    st.session_state["case2_mode"] = mode
    st.session_state["case2_reply"] = result["reply"]
    st.session_state.pop("case2_image_result", None)
    st.session_state.pop("case2_image", None)


with st.sidebar:
    st.subheader("Connections")
    st.write(f"**Case 2 API:** `{BASE}`")
    st.write(f"**Tenant:** `{tenant}`")
    try:
        service = request_json(BASE, "GET", "/health", timeout=4)
        st.success("Chatbot API running")
        st.caption(f"CV backend: {service.get('cv_dependency')}")
    except APIError as exc:
        st.error(str(exc))
    st.divider()
    page = st.radio("Section", ["Chatbot", "Pilot feedback & metrics", "Business options & discovery"])

if page == "Chatbot":
    st.subheader("Interact with the product assistant")
    mode = st.selectbox("Choose a pilot option", ["manual", "cv", "advanced"],
        format_func=lambda x: {"manual":"1 · Manual / rules baseline",
                               "cv":"2 · Computer vision + guided chatbot",
                               "advanced":"3 · Advanced-assisted chatbot"}[x])
    st.caption("Advanced mode calls an external vision-language model ONLY if its optional server configuration is enabled. Otherwise it remains a guided CV demo.")
    if st.button("Start new conversation", type="primary"):
        try:
            new_session(mode)
            st.rerun()
        except APIError as exc:
            st.error(str(exc))
    session = st.session_state.get("case2_session")
    if session:
        active_mode = st.session_state.get("case2_mode", mode)
        st.caption(f"Session `{session[:12]}…` · Option `{active_mode}`")
        if active_mode != mode:
            st.warning("The current session uses your previous mode. Start a new conversation to switch options.")
        if active_mode != "manual":
            col1, col2 = st.columns([3, 2])
            with col1:
                picture = st.file_uploader("Upload a product/room image", type=["png","jpg","jpeg","webp"],
                                           key=f"case2_upload_{session}")
                samples = sorted((ROOT / "data" / "samples").glob("*.png"))
                sample_choice = st.selectbox("Or choose a supplied synthetic sample",
                                              ["None"] + [p.name for p in samples])
            with col2:
                if picture:
                    st.image(picture, caption=picture.name, width=280)
                elif sample_choice != "None":
                    st.image(ROOT / "data" / "samples" / sample_choice, width=280)
            payload, filename = (picture.getvalue(), picture.name) if picture else (None, "")
            if not payload and sample_choice != "None":
                file_path = ROOT / "data" / "samples" / sample_choice
                payload, filename = file_path.read_bytes(), file_path.name
            if st.button("Analyze uploaded image", disabled=not payload):
                try:
                    with st.spinner("Using Case 2 -> Case 1 inference service..."):
                        result = api("POST", f"/v1/sessions/{session}/image", image=payload, filename=filename)
                    st.session_state["case2_image_result"] = result
                    st.session_state["case2_image"] = payload
                    st.rerun()
                except APIError as exc:
                    st.error(str(exc))
        try:
            transcript = api("GET", f"/v1/sessions/{session}")
            for item in transcript.get("messages", []):
                role = "assistant" if item["role"] == "assistant" else "user"
                with st.chat_message(role):
                    st.write(item["message"])
            suggestions = transcript.get("suggestions", [])
            if suggestions:
                st.subheader("Catalogue suggestions (category match only)")
                st.dataframe(suggestions, width="stretch", hide_index=True)
                if st.button("Confirm option 1", key="case2_choose"):
                    try:
                        api("POST", f"/v1/sessions/{session}/message", json_data={"message":"choose 1"})
                        st.rerun()
                    except APIError as exc:
                        st.error(str(exc))
            response = st.chat_input("Ask: show options, why confidence, correct chair, choose 1, human")
            if response:
                try:
                    api("POST", f"/v1/sessions/{session}/message", json_data={"message":response})
                    st.rerun()
                except APIError as exc:
                    st.error(str(exc))
        except APIError as exc:
            st.error(str(exc))
    else:
        st.write("Choose a mode and select **Start new conversation** to begin.")

elif page == "Pilot feedback & metrics":
    st.subheader("Evidence-first pilot")
    st.write("Compare how much time users spend, whether they accept suggestions, and what types of errors occur.")
    session = st.session_state.get("case2_session")
    if session:
        st.caption(f"Active session: `{session[:12]}…` — record one genuine observation per session.")
        try:
            catalogue = api("GET", "/v1/catalog").get("items", [])
            choices = [""] + [row["sku"] for row in catalogue]
        except APIError:
            choices = [""]
        with st.form("pilot_observation"):
            accepted = st.checkbox("User accepted the proposed category/product", value=False)
            actual_sku = st.selectbox("Actual verified catalogue SKU (optional)", choices)
            m1, m2, m3 = st.columns(3)
            manual_minutes = m1.number_input("Manual baseline (min)", 0.0, 999.0, 5.0, step=0.5)
            assisted_minutes = m2.number_input("Assisted time (min)", 0.0, 999.0, 3.0, step=0.5)
            cost_usd = m3.number_input("Cost per task (USD)", 0.0, 999.0, 0.02, step=0.01)
            error_type = st.selectbox("Error type", ["none", "false_positive", "miss", "wrong_sku", "unknown"])
            if st.form_submit_button("Record pilot observation"):
                try:
                    result = api("POST", f"/v1/sessions/{session}/feedback",
                        json_data={"accepted":accepted,"actual_sku":actual_sku or None,
                                   "manual_minutes":manual_minutes,"assisted_minutes":assisted_minutes,
                                   "cost_usd":cost_usd,"error_type":error_type})
                    st.success(result.get("note", "Saved"))
                except APIError as exc:
                    st.error(str(exc))
    else:
        st.info("Start a chatbot conversation before recording its pilot result.")
    if st.button("Refresh pilot results", type="primary"):
        try:
            st.session_state["case2_metrics"] = api("GET", "/v1/pilot/metrics")
            st.session_state["case2_decision"] = api("GET", "/v1/pilot/decision")
        except APIError as exc:
            st.error(str(exc))
    metrics = st.session_state.get("case2_metrics")
    if metrics:
        c1, c2 = st.columns(2)
        c1.metric("Recorded observations", metrics.get("recorded_observations", 0))
        improvement = metrics.get("estimated_cv_time_reduction_vs_manual_baseline")
        c2.metric("CV task-time change", "Not enough data" if improvement is None else f"{improvement:.0%}")
        st.write("**Pilot comparison**")
        st.dataframe([{"option":mode,**values} for mode, values in metrics.get("by_mode", {}).items()],
                     hide_index=True, width="stretch")
        st.write("**Go/no-go gates**")
        st.json(st.session_state.get("case2_decision"))
        st.warning("The demo's manually entered observations are not a validated business study or causal effect.")

else:
    st.subheader("Discovery, alternatives and go/no-go criteria")
    if st.button("Load option comparison and discovery questions", type="primary"):
        try:
            st.session_state["case2_options"] = api("GET", "/v1/pilot/options")
            st.session_state["case2_discovery"] = api("GET", "/v1/pilot/discovery")
        except APIError as exc:
            st.error(str(exc))
    options = st.session_state.get("case2_options")
    if options:
        st.dataframe(options.get("options", []), width="stretch", hide_index=True)
        st.success("Recommended first pilot: CV suggestions + human confirmation, after measuring a manual baseline.")
    questions = st.session_state.get("case2_discovery")
    if questions:
        st.markdown("### Questions for each stakeholder")
        for group, entries in questions.items():
            with st.expander(group.replace("_", " ").title()):
                for entry in entries:
                    st.write("•", entry)
    st.markdown("### Explaining the 99% accuracy request")
    st.write("Ask what 'accuracy' means (per-object detection, exact SKU or accepted recommendation), "
             "measure uncertainty using a representative, reviewed test set, and propose a narrower pilot "
             "or human-review fallback if the target cannot be justified by available data.")
