"""Case Study 1 Streamlit: detection, import, web imagery, QA, monitoring.

Start alongside the Case 1 FastAPI backend:
    streamlit run ui/case1_streamlit.py --server.port 8501
"""
from __future__ import annotations
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import streamlit as st
from ui.common import APIError, preview_with_boxes, request_json, tenant_credentials
from ui.datasets import (collect_web_images, import_uploaded_yolo_zip,
                         list_manifests, validate_manifests)

st.set_page_config(page_title="Case 1 · Computer Vision POC", page_icon="🔍", layout="wide")
BASE = os.getenv("CASE1_URL", "http://127.0.0.1:8001")
tenant, key = tenant_credentials()
st.title("Case Study 1 · Computer Vision")
st.caption("FastAPI inference · dataset quality · per-customer monitoring · controlled releases")
st.info("The default **marker-v1** model detects colored shapes in the supplied sample images only. "
        "To recognize real photos, install and activate an optional real detector. No accuracy is claimed for unreviewed images.")


def get(path: str, **kwargs) -> dict:
    return request_json(BASE, "GET", path, tenant=tenant, api_key=key, **kwargs)


def post(path: str, **kwargs) -> dict:
    return request_json(BASE, "POST", path, tenant=tenant, api_key=key, **kwargs)


with st.sidebar:
    st.subheader("Connections")
    st.write(f"**Case 1 API:** `{BASE}`")
    st.write(f"**POC tenant:** `{tenant}`")
    try:
        status = request_json(BASE, "GET", "/health", timeout=4)
        st.success("Detector API running")
    except APIError as exc:
        st.error(str(exc))
    st.divider()
    page = st.radio("Section", ["Detect image", "Dataset import & validation", "Monitoring", "Model release"],
                    label_visibility="visible")
    st.caption("Only use images you have permission to upload or analyze.")

if page == "Detect image":
    st.subheader("Upload an image and visualize bounding boxes")
    upload = st.file_uploader("Choose a PNG, JPEG, or WebP image", type=["png","jpg","jpeg","webp"],
                              key="case1_image")
    samples = [p for p in (ROOT / "data" / "samples").glob("*.png")]
    sample_choice = st.selectbox("Or use a sample marker image", ["No sample"] + [p.name for p in samples])
    uploaded_image = upload.getvalue() if upload else None
    name = upload.name if upload else None
    if not uploaded_image and sample_choice != "No sample":
        path = ROOT / "data" / "samples" / sample_choice
        uploaded_image, name = path.read_bytes(), path.name
    if uploaded_image:
        st.image(uploaded_image, caption="Original image", width=350)
    if st.button("Detect objects", type="primary", disabled=not uploaded_image):
        try:
            with st.spinner("Calling FastAPI detector..."):
                result = post("/v1/predict", image=uploaded_image, filename=name or "upload.png")
            st.session_state["case1_last_result"] = result
            st.session_state["case1_last_image"] = uploaded_image
        except (APIError, OSError, ValueError) as exc:
            st.error(str(exc))
    result = st.session_state.get("case1_last_result")
    if result:
        st.caption(f"Prediction: `{result['prediction_id']}` · Model: `{result['model_version']}` · Backend: `{result['backend']}`")
        if result.get("demo_only"):
            st.warning("Synthetic marker detection, not furniture recognition. Don't use demo results as accuracy evidence.")
        c1, c2, c3 = st.columns(3)
        c1.metric("Objects detected", len(result.get("detections", [])))
        c2.metric("Inference latency", f"{result.get('latency_ms', 0):.1f} ms")
        c3.metric("Tenant", result.get("tenant_id", tenant))
        confidence_floor = st.slider("Minimum displayed confidence", 0.0, 1.0, 0.2, step=0.05)
        try:
            rendered = preview_with_boxes(st.session_state["case1_last_image"],
                                          result.get("detections", []), confidence_floor)
            st.image(rendered, caption="Predicted bounding boxes", width="stretch")
        except (OSError, ValueError) as exc:
            st.warning(f"Cannot display overlay: {exc}")
        st.dataframe(result.get("detections", []), width="stretch", hide_index=True)
        st.subheader("Human feedback")
        with st.form("case1_feedback"):
            accepted = st.radio("Were the suggestions useful?", ["Yes", "No"], horizontal=True)
            missed = st.text_input("Missed categories (comma separated)", placeholder="chair, sofa")
            corrected = st.text_input("Corrected categories (comma separated)", placeholder="table")
            if st.form_submit_button("Save feedback"):
                payload = {"accepted":accepted == "Yes",
                           "missed_labels":[x.strip() for x in missed.split(",") if x.strip()][:20],
                           "corrected_labels":[x.strip() for x in corrected.split(",") if x.strip()][:20]}
                try:
                    post(f"/v1/predictions/{result['prediction_id']}/feedback", json_data=payload)
                    st.success("Feedback saved for review. This does not create verified ground-truth labels.")
                except APIError as exc:
                    st.error(str(exc))

elif page == "Dataset import & validation":
    st.subheader("Import a labeled dataset and validate its quality")
    st.markdown("**Suggested flow:** import → check image/box integrity → inspect leakage → approve annotations → freeze an independent test set.")
    tab_demo, tab_zip, tab_web, tab_validate = st.tabs([
        "Offline sample", "YOLO ZIP upload", "Web-image collection", "Validation reports"])
    with tab_demo:
        st.write("Import the **three supplied synthetic sample images** into an auditable CSV manifest.")
        if st.button("Import synthetic examples", key="import_demo"):
            try:
                from scripts.import_demo_dataset import main as import_demo
                import_demo()
                report = validate_manifests(ROOT / "data/demo_import/images_manifest.csv",
                                            ROOT / "data/demo_import/boxes.csv")
                st.success("Demo images and synthetic bounding boxes imported")
                st.json(report)
            except (ValueError, OSError) as exc:
                st.error(str(exc))
    with tab_zip:
        st.write("Upload a **licensed, already-annotated YOLO-format** ZIP containing `data.yaml`, "
                 "`train/images`, `train/labels`, `valid/images`, `valid/labels`, `test/images`, and `test/labels`.")
        zip_file = st.file_uploader("YOLO dataset ZIP", type="zip", key="case1_yolo_zip")
        qa_completed = st.checkbox("I confirm bounding boxes have been reviewed by a human annotator", value=False)
        st.caption("If unchecked, the images can be inspected, but labels are NOT treated as verified ground truth.")
        if st.button("Import & run quality checks", disabled=zip_file is None, key="import_yolo"):
            try:
                with st.spinner("Extracting and auditing dataset..."):
                    result = import_uploaded_yolo_zip(zip_file.getvalue(), tenant, qa_completed)
                st.success(f"Imported {result['images']} images into `{result['dataset_id']}`")
                st.json(result)
            except (ValueError, OSError, KeyError, RuntimeError, ImportError) as exc:
                st.error(str(exc))
    with tab_web:
        st.write("Optional **Wikimedia Commons** image collection using its official API or "
                 "HTML category-gallery discovery. Each image is checked for its license and source credit.")
        st.warning("These images are **unlabeled visual test examples**. Search category names are not bounding-box ground truth; "
                   "review boxes before calculating mAP, recall or precision.")
        contact = st.text_input("Contact email for Wikimedia requests (User-Agent)",
                                placeholder="your-contact@example.com")
        categories = st.multiselect("Furniture categories", ["Chairs", "Sofas", "Dining_tables", "Beds"],
                                     default=["Chairs", "Sofas"])
        per_category = st.slider("Images per category", min_value=1, max_value=6, value=2)
        discovery = st.radio("Discovery mode", ["api", "html"], horizontal=True,
                             help="Both modes resolve final image/license metadata through Wikimedia's API.")
        if st.button("Collect licensed web examples", disabled=not contact or not categories):
            try:
                with st.spinner("Collecting images respectfully; this requires internet access..."):
                    result = collect_web_images(contact.strip(), categories, per_category, discovery)
                st.json(result)
                if result["images_collected"]:
                    st.success("Downloaded examples and stored source/license credits in data/web_test/CREDITS.md")
                else:
                    st.warning("No eligible images collected; check connectivity, site policies or category coverage.")
            except Exception as exc:  # Network/robots/licensing failures are optional POC errors
                st.error(f"Web collection could not complete: {exc}")
    with tab_validate:
        available = list_manifests()
        if not available:
            st.info("Import a demo, a labeled ZIP, or web examples first.")
        else:
            selected = st.selectbox("Dataset to inspect", available, format_func=lambda x: f"{x['name']} ({x['count']} images)")
            if st.button("Validate dataset", type="primary"):
                try:
                    report = validate_manifests(selected["manifest"], selected["manifest"].parent / "boxes.csv")
                    st.session_state["case1_validation"] = report
                except (ValueError, OSError) as exc:
                    st.error(str(exc))
            report = st.session_state.get("case1_validation")
            if report:
                (st.success if report["status"] == "PASS" else st.error)("Validation: " + report["status"])
                st.json(report)
                st.download_button("Download validation report (JSON)",
                    data=__import__("json").dumps(report, indent=2),
                    file_name="dataset_validation_report.json", mime="application/json")

elif page == "Monitoring":
    st.subheader("Tenant-level monitoring")
    st.write("The case study specifically requires detection of customer-specific issues hidden by aggregate numbers.")
    if st.button("Refresh monitoring", type="primary"):
        try:
            st.session_state["case1_metrics"] = get("/v1/analytics/tenant")
            st.session_state["case1_drift"] = get("/v1/analytics/drift")
        except APIError as exc:
            st.error(str(exc))
    metrics = st.session_state.get("case1_metrics")
    if metrics:
        cols = st.columns(4)
        for col, label, value in zip(cols,
             ("Predictions", "Feedback samples", "Reported miss rate", "p95 latency (ms)"),
             (metrics.get("prediction_count"), metrics.get("feedback_count"),
              metrics.get("user_reported_miss_rate"), metrics.get("p95_latency_ms"))):
            col.metric(label, "N/A" if value is None else value)
        st.json(metrics)
        st.markdown("**Image-quality shift** (brightness and contrast, not full semantic drift)")
        st.json(st.session_state.get("case1_drift", {}))
    st.caption("User-reported misses are feedback proxies, not true recall. Actual recall requires verified bounding-box labels.")

else:
    st.subheader("Model registry, canary rollout and rollback")
    st.warning("Local demo control only. Do not expose administrator keys publicly.")
    admin_key = st.text_input("Demo admin key", type="password", value=os.getenv("ADMIN_KEY", "local-admin-demo-key"))
    if st.button("View model registry"):
        try:
            models = request_json(BASE, "GET", "/v1/admin/models", admin_key=admin_key)
            st.session_state["case1_models"] = models
        except APIError as exc:
            st.error(str(exc))
    if st.session_state.get("case1_models"):
        st.json(st.session_state["case1_models"])
    st.write("Start with `marker-v1` and `marker-v2` to demonstrate release controls safely.")
    with st.form("rollout"):
        active = st.selectbox("Primary model", ["marker-v1", "marker-v2", "yolo11n", "fasterrcnn"])
        canary = st.selectbox("Optional canary", ["None", "marker-v1", "marker-v2", "yolo11n"])
        fraction = st.slider("Canary traffic percent", 0, 100, 0)
        if st.form_submit_button("Apply rollout"):
            try:
                result = request_json(BASE, "POST", "/v1/admin/models/rollout", admin_key=admin_key,
                    json_data={"active":active,"canary":None if canary == "None" else canary,
                               "canary_percent":fraction})
                st.success("Model routing updated")
                st.json(result)
            except APIError as exc:
                st.error(str(exc))
    if st.button("Rollback to previous validated configuration"):
        try:
            st.json(request_json(BASE,"POST","/v1/admin/models/rollback",admin_key=admin_key))
        except APIError as exc:
            st.error(str(exc))
