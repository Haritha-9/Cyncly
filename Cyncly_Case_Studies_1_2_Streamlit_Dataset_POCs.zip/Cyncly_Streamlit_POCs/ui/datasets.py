"""Dataset preparation functions that the UI can safely call and unit-test.

All downloads from Wikimedia Commons remain optional. No web labels count as truth.
"""
from __future__ import annotations
from pathlib import Path, PurePosixPath
import io
import json
import shutil
import stat
import tempfile
from uuid import uuid4
import zipfile

from dataset_tools.common import read_csv
from scripts.import_yolo_dataset import import_dataset
from scripts.validate_dataset import validate_dataset

ROOT = Path(__file__).resolve().parents[1]
DATASETS = ROOT / "data" / "ui_datasets"


def safe_extract_yolo_zip(data: bytes, folder: Path, *, max_size: int = 280_000_000,
                          max_members: int = 2500) -> Path:
    """Prevent ZIP-slip, symlink escapes, zip bombs and executable file imports."""
    if len(data) > 85_000_000:
        raise ValueError("ZIP upload exceeds the 85 MB limit")
    folder.mkdir(parents=True, exist_ok=True)
    allowed = {".jpg", ".jpeg", ".png", ".webp", ".txt", ".yaml", ".yml"}
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        infos = archive.infolist()
        if not infos or len(infos) > max_members:
            raise ValueError("ZIP is empty or has too many files")
        if sum(z.file_size for z in infos) > max_size:
            raise ValueError("ZIP expands above 280 MB limit")
        for item in infos:
            name = item.filename.replace("\\", "/")
            parts = PurePosixPath(name)
            if (parts.is_absolute() or ".." in parts.parts or
                any(x in {"", "."} for x in parts.parts) or
                ":" in name or (item.external_attr >> 16) & 0o170000 == stat.S_IFLNK):
                raise ValueError(f"Unsafe ZIP path: {name}")
            if item.is_dir() or name.startswith("__MACOSX/"):
                continue
            if Path(name).suffix.lower() not in allowed:
                raise ValueError(f"Unexpected ZIP file type: {name}")
            target = (folder / name).resolve()
            if not target.is_relative_to(folder.resolve()):
                raise ValueError("ZIP path escapes extraction folder")
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(item) as src, target.open("wb") as dst:
                shutil.copyfileobj(src, dst, length=256 * 1024)
        yaml_candidates = list(folder.rglob("data.yaml"))
        if len(yaml_candidates) != 1:
            raise ValueError("Expected exactly one data.yaml inside the YOLO dataset ZIP")
        return yaml_candidates[0].parent


def import_uploaded_yolo_zip(zip_bytes: bytes, tenant: str, reviewed: bool,
                             *, out_root: Path = DATASETS) -> dict:
    dataset_id = "yolo_" + uuid4().hex[:12]
    output = out_root / dataset_id
    with tempfile.TemporaryDirectory(prefix="cyncly_yolo_") as temp:
        source = safe_extract_yolo_zip(zip_bytes, Path(temp))
        result = import_dataset(source, output, tenant, reviewed)
    check = validate_manifests(output / "images_manifest.csv", output / "boxes.csv")
    return {**result, "dataset_id": dataset_id, "validation": check}


def validate_manifests(images_file: Path, boxes_file: Path | None = None) -> dict:
    image_rows = read_csv(images_file)
    box_rows = read_csv(boxes_file) if boxes_file and boxes_file.exists() else []
    return validate_dataset(image_rows, box_rows, ROOT)


def list_manifests() -> list[dict]:
    results = []
    # Only fixed, app-owned folders, no user-defined filesystem browsing.
    for base in (ROOT / "data" / "demo_import", ROOT / "data" / "web_test", DATASETS):
        if not base.exists():
            continue
        for manifest in sorted(base.rglob("images_manifest.csv")):
            if not manifest.resolve().is_relative_to((ROOT / "data").resolve()):
                continue
            try:
                rows = read_csv(manifest)
                results.append({"name": str(manifest.parent.relative_to(ROOT)),
                                "count": len(rows), "manifest": manifest})
            except OSError:
                continue
    return results


def collect_web_images(contact: str, categories: list[str], per_category: int,
                       discovery: str = "api") -> dict:
    """Request licensed images from Commons, not arbitrary third-party websites."""
    if not categories or per_category < 1 or per_category > 6:
        raise ValueError("Select categories and request at most 6 images per category")
    from scripts.scrape_test_images import CommonsClient, collect
    output = ROOT / "data" / "web_test"
    existing_manifest = ROOT / "data" / "demo_import" / "images_manifest.csv"
    existing = read_csv(existing_manifest) if existing_manifest.exists() else []
    result = collect(CommonsClient(contact, delay=1.5), output, categories,
                     per_category, discovery=discovery, max_pages=2, existing=existing)
    result["validation"] = validate_manifests(output / "images_manifest.csv", output / "boxes.csv")
    return result
